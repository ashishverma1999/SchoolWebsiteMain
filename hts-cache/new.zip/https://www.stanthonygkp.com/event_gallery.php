<!DOCTYPE>
<html>
<!-- Mirrored from php.themewant.com/unipix/index-two.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 May 2025 07:44:43 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Anthony’s Convent School</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/emblem%201.jpg">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- fontawesome 6.4.2 -->
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <!-- bootstrap min css -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- swiper Css 10.2.0 -->
    <link rel="stylesheet" href="assets/css/plugins/swiper.min.css">
    <!-- Bootstrap 5.0.2 -->
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <!-- metismenu scss -->
    <link rel="stylesheet" href="assets/css/vendor/metismenu.css">
    <!-- nice select js -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <!-- custom style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/flexslider.css" rel="stylesheet" />

</head>

<body>
    <!-- Top Contact Bar -->
    <div class="top-bar">
        <div class="top-bar-container">
            <div class="contact-details">
                📞 <a href="tel:+919876543210">0551-228 0250</a> &nbsp; | &nbsp;
                📧 <a href="mailto:stanthony100@gmail.com">stanthony100@gmail.com</a>
               <span style="padding-left:12px;">Affiliation Number- 2131306</span>
            </div>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/16NQD98XaQ/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://youtube.com/@stanthonyconvent5802" target="_blank"><i class="fab fa-youtube"></i></a>
                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
    <!-- header area start -->
    <header class="header header__sticky v__2">
        <div class="container-fluid header11topDown">
            <div class="row">
                <div class="col-xl-12">
                    <div class="header__wrapper">
                        <div class="header__logo d-flex align-items-center">
                            <a href="index.php" class="d-flex align-items-center text-decoration-none">
                                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                                <div class="school-name text-dark">
                                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>

                        <div class="header__menu">
                            <div class="navigation">
                                <nav class="navigation__menu">
                                    <ul>
                                        <li class="navigation__menu--item has-child">
                                            <a href="index.php" class="navigation__menu--item__link">Home</a>
                                             
                                        </li> 
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">About Us</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                                                                <li><a href="principal.php">Principal Desk </a></li>
                                            </ul>
                                        </li>

                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Curriculam</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                                                                            </ul>
                                        </li>
                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Facilities</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                                                                            </ul>
                                        </li>

                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Achievements</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="toppers-x.php">Toppers X</a></li>
                                                <li><a href="toppers-xii.php">Toppers XII</a></li>
                                            </ul>
                                        </li>

                                         
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Gallery</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="event_gallery.php">Event Gallery</a></li>
                                                <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                                            </ul>
                                        </li>
                                         <li class="navigation__menu--item has-child">
                                            <a href="tc.php" class="navigation__menu--item__link">Tc</a>
                                             
                                        </li> 

                                        <li class="navigation__menu--item">
                                            <a href="contact.php" class="navigation__menu--item__link">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="header__right">
                            <div class="header__right--item">
                                <div id="menu-btn" class="menu__trigger">
                                    <i class="fa-solid fa-bars"></i>
                                    <!--<img src="assets/images/icon/menu__bar.svg" alt="bar">-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>




     


<section class="rts-breadcrumb breadcrumb-height breadcumb-bg" style="background-image: url(assets/images/banner/2.jpeg);">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-content">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Gallery</li>
                    </ul>
                    <h2 class="section-title">Our School Life</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- BREADCRUMB AREA END -->

<!-- Gallery Section with Tabs -->
<div class="rts-gallery rts-section-padding">
    <div class="container">
        <!-- Tabs Navigation -->
        <ul class="nav nav-tabs justify-content-center mb-4" id="galleryTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="true">All</button>
            </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-17-tab" data-bs-toggle="tab" data-bs-target="#category-17" type="button" role="tab" aria-controls="category-17" aria-selected="false">Our School</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-18-tab" data-bs-toggle="tab" data-bs-target="#category-18" type="button" role="tab" aria-controls="category-18" aria-selected="false">Events</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-21-tab" data-bs-toggle="tab" data-bs-target="#category-21" type="button" role="tab" aria-controls="category-21" aria-selected="false">Independence Day </button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-23-tab" data-bs-toggle="tab" data-bs-target="#category-23" type="button" role="tab" aria-controls="category-23" aria-selected="false">Teacher Day</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-24-tab" data-bs-toggle="tab" data-bs-target="#category-24" type="button" role="tab" aria-controls="category-24" aria-selected="false">KG Day Celebration</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-26-tab" data-bs-toggle="tab" data-bs-target="#category-26" type="button" role="tab" aria-controls="category-26" aria-selected="false">Seminar for the parents of primary students.</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-27-tab" data-bs-toggle="tab" data-bs-target="#category-27" type="button" role="tab" aria-controls="category-27" aria-selected="false">Book Fair</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-29-tab" data-bs-toggle="tab" data-bs-target="#category-29" type="button" role="tab" aria-controls="category-29" aria-selected="false">Talento Exhibition</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-30-tab" data-bs-toggle="tab" data-bs-target="#category-30" type="button" role="tab" aria-controls="category-30" aria-selected="false">ALUMNI MEET 2026</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-31-tab" data-bs-toggle="tab" data-bs-target="#category-31" type="button" role="tab" aria-controls="category-31" aria-selected="false">Earth Day Celebration</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-32-tab" data-bs-toggle="tab" data-bs-target="#category-32" type="button" role="tab" aria-controls="category-32" aria-selected="false">Vidyaarambh 2026-27</button>
                </li>
                            <li class="nav-item" role="presentation">
                    <button class="nav-link" id="category-34-tab" data-bs-toggle="tab" data-bs-target="#category-34" type="button" role="tab" aria-controls="category-34" aria-selected="false">YELLOW DAY</button>
                </li>
                    </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="galleryTabContent">
            <!-- All Images Tab -->
            <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                <div class="row g-5">
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/43WhatsApp Image 2026-04-29 at 10.49.18 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/60DSC_0534.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/15WhatsApp Image 2026-04-27 at 1.12.23 AM (1).jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/92WhatsApp Image 2026-04-27 at 1.12.24 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/69WhatsApp Image 2026-04-27 at 1.12.25 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/43WhatsApp Image 2026-04-27 at 1.12.25 AM (1).jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/37WhatsApp Image 2026-01-23 at 11.55.36 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/49WhatsApp Image 2026-01-23 at 11.55.35 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/65WhatsApp Image 2026-01-23 at 11.55.35 AM (2).jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/40WhatsApp Image 2026-01-23 at 11.55.35 AM (1).jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/57DSC_1163.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/2920251220_110737.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/49DSC_1175.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/72DSC_1173.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/6DSC_1041.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/88se2.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/75se5.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/13se3.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/56se4.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/88boo.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/5DSC_1094.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/15DSC_1097.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/36DSC_1099.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/16DSC_0692.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/17DSC_0738.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/69DSC_0798.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/29DSC_0661.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/43DSC_0768.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/75DSC_0667.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/43DSC_0680.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/19DSC_0649.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/65DSC_0656.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/51DSC_0730.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/15WhatsApp Image 2025-09-04 at 7.51.47 PM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/67WhatsApp Image 2025-09-04 at 7.52.28 PM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/93WhatsApp Image 2025-09-04 at 11.36.43 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/57DSC_0498.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/30DSC_0497.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/89DSC_0489.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/89DSC_0423.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/91DSC_0419.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/18DSC_0406.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/69DSC_0403.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/25DSC_0395.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/38DSC_0389.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/58DSC_0385.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/89DSC_0382.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/75DSC_0372.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/20DSC_0364.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/20DSC_0357.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/61DSC_0355.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/2DSC_0355.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/31DSC_0350.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/1DSC_0339.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/10DSC_0339.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/16IMG-20250815-WA0014.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/39IMG-20250815-WA0032.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/9IMG-20250815-WA0012.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/94IMG-20250815-WA0022.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/72IMG-20250815-WA0009.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/44IMG-20250815-WA0010.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/2IMG-20250815-WA0032.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/19IMG-20250815-WA0016.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/23IMG-20250815-WA0022.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/66IMG-20250815-WA0033.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/80IMG-20250815-WA0019.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/10IMG-20250815-WA0024.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/58IMG-20250815-WA0023.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/16IMG-20250815-WA0026.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/77IMG-20250815-WA0025.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/90IMG-20250815-WA0035.jpg" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/79DSC_0075.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-item">
                                    <div class="single-item__image">
                                                                                    <img src="upload/gallery/99DSC_0453.JPG" alt="Gallery Image" class="img-fluid">
                                                                            </div>
                                </div>
                            </div>
                                    </div>
            </div>

            <!-- Category Tabs -->
                            <div class="tab-pane fade" id="category-17" role="tabpanel" aria-labelledby="category-17-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/99DSC_0453.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-18" role="tabpanel" aria-labelledby="category-18-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/79DSC_0075.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/10DSC_0339.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/51DSC_0730.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/43WhatsApp Image 2026-04-29 at 10.49.18 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-21" role="tabpanel" aria-labelledby="category-21-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/90IMG-20250815-WA0035.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/77IMG-20250815-WA0025.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/16IMG-20250815-WA0026.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/58IMG-20250815-WA0023.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/10IMG-20250815-WA0024.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/80IMG-20250815-WA0019.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/66IMG-20250815-WA0033.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/23IMG-20250815-WA0022.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/19IMG-20250815-WA0016.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/2IMG-20250815-WA0032.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/44IMG-20250815-WA0010.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/72IMG-20250815-WA0009.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/94IMG-20250815-WA0022.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/9IMG-20250815-WA0012.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/39IMG-20250815-WA0032.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/16IMG-20250815-WA0014.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-23" role="tabpanel" aria-labelledby="category-23-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/1DSC_0339.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/31DSC_0350.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/2DSC_0355.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/61DSC_0355.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/20DSC_0357.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/20DSC_0364.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/75DSC_0372.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/89DSC_0382.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/58DSC_0385.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/38DSC_0389.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/25DSC_0395.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/69DSC_0403.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/18DSC_0406.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/91DSC_0419.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/89DSC_0423.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/89DSC_0489.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/30DSC_0497.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/57DSC_0498.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/93WhatsApp Image 2025-09-04 at 11.36.43 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/67WhatsApp Image 2025-09-04 at 7.52.28 PM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/15WhatsApp Image 2025-09-04 at 7.51.47 PM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-24" role="tabpanel" aria-labelledby="category-24-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/65DSC_0656.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/19DSC_0649.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/43DSC_0680.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/75DSC_0667.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/43DSC_0768.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/29DSC_0661.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/69DSC_0798.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/17DSC_0738.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/16DSC_0692.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-26" role="tabpanel" aria-labelledby="category-26-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/56se4.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/13se3.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/75se5.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/88se2.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/6DSC_1041.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-27" role="tabpanel" aria-labelledby="category-27-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/36DSC_1099.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/15DSC_1097.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/5DSC_1094.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/88boo.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-29" role="tabpanel" aria-labelledby="category-29-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/72DSC_1173.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/49DSC_1175.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/2920251220_110737.jpg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/57DSC_1163.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-30" role="tabpanel" aria-labelledby="category-30-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/40WhatsApp Image 2026-01-23 at 11.55.35 AM (1).jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/65WhatsApp Image 2026-01-23 at 11.55.35 AM (2).jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/49WhatsApp Image 2026-01-23 at 11.55.35 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/37WhatsApp Image 2026-01-23 at 11.55.36 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-31" role="tabpanel" aria-labelledby="category-31-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/43WhatsApp Image 2026-04-27 at 1.12.25 AM (1).jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/69WhatsApp Image 2026-04-27 at 1.12.25 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/92WhatsApp Image 2026-04-27 at 1.12.24 AM.jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/15WhatsApp Image 2026-04-27 at 1.12.23 AM (1).jpeg" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-32" role="tabpanel" aria-labelledby="category-32-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="upload/gallery/60DSC_0534.JPG" alt="Gallery Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                            <div class="tab-pane fade" id="category-34" role="tabpanel" aria-labelledby="category-34-tab">
                    <div class="row g-5">
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                                        <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div class="single-item">
                                        <div class="single-item__image">
                                                                                            <img src="assets/images/campus/default.jpg" alt="Default Image" class="img-fluid">
                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
                    </div>
    </div>
</div>
<!-- Gallery Section End -->



<!-- footer start -->
    <footer class="rts-footer rts-footer-padding v_2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="rts-footer-newsletter">
                    <div class="col-lg-10">
                        <div class="rts-newsletter-box-content">
                            <h4 class="newsletter-title">Subscribe To Newsletter
                            </h4>
                            <div class="newsletter-form w-530">
                                <form action="#">
                                    <input type="email" name="subscription" id="subscription" placeholder="Enter Your mail" required="">
                                    <button type="submit" class="rts-nbg-btn btn-arrow">Subscribe <span><i class="fa-sharp fa-regular fa-arrow-right"></i></span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row gy-5 gy-lg-0">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="rts-footer-widget w-320">
                        <div class="header__logo" style="display: flex; align-items: center;">
                            <a href="index.php" style="display: flex; align-items: center; text-decoration: none;">
                                <img src="assets/images/logo/emblem 1.png"
                                    alt="St. Anthony’s Convent School Logo"
                                    height="80" width="80"
                                    style="border-radius: 50%; object-fit: cover; margin-right: 10px; border: 2px solid #ccc;">
                                
                                <div style="color: #000;">
                                    <h5 style="margin: 0; font-weight: bold; font-size: 18px; line-height: 1.2;color:white">
                                        St. Anthony’s Convent School
                                    </h5>
                                    <small style="font-size: 13px; color: #6c757d;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>


                        <p>
                            We are passionate education dedicated to providing high-quality
                            resources learners all backgrounds.
                        </p>
                        <div class="rts-contact-link">
                            <a href="mailto:stanthony100@gmail.com"><i class="fa-sharp fa-light fa-location-dot"></i> Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                            <a href="callto:0551-228 0250"><i class="fa-thin fa-phone"></i> 0551-228 0250</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="rts-footer-widget ">
                        <h6 class="rt-semi">Important Links</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#"> Blogs</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-4">
                    <div class="rts-footer-widget ml--30">
                        <h6 class="rt-semi">About Us</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Our History </a></li>
                                <li><a href="About.php">About Us</a></li>
                                <li><a href="#">St. Anthony</a></li>
                                <li><a href="#">Our Mission</a></li>
                                <li><a href="#">Our Vision</a></li>
                                 <li><a href="#">Our Motto</a></li>
                                <li><a href="#">School Anthem</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="rts-footer-widget ml--30">
                        
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="rts-footer-copy-right v_1">
        <div class="container">
            <div class="row">
                <div class="rt-center">
                    <p class="--p-xs">Copyright &copy; <span id="year"></span> All Rights Reserved by <a href="#">St. Anthony’s Convent School</a></p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer end -->
    <!-- offcanvase menu -->
    <!-- header style two -->
    <div id="side-bar" class="side-bar">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                
               <a href="index.php" class="d-flex align-items-center text-decoration-none">
                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                <div class="school-name text-dark">
                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                </div>
            </a>
            </div>
            <div class="inner-content">
                <p class="disc">
                    A modern php template for education, offering intuitive design & essential features for seamless learning experiences.
                </p>
                <!-- offcanvase banner -->
                <div class="offcanvase__banner mt--50">
                    <div class="offcanvase__banner--content">
                        <img src="assets/images/offcanvase.jpg" alt="offcanvase">
                        <a href="admission.php" class="rts-theme-btn">Apply Now</a>
                    </div>
                </div>
                <div class="offcanvase__info">
                    <div class="offcanvase__info--content">
                        <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                        <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                        <div class="offcanvase__info--content--social">
                            <p class="title">Follow Us:</p>
                            <div class="social__links">
                                <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
            <ul class="mainmenu metismenu" id="mobile-menu-active">
                <li>
                    <a href="index.php" class="main">Home</a>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">About Us</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                 <li>
                            <a href="principal.php" class="main">Principal Desk</a>
                        </li>
                    </ul>
                </li>
                
                <!-- Curriculum - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Curriculum</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                            </ul>
                </li>
                
                <!-- Facilities - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Facilities</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                            </ul>
                </li>

                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Achievements</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="toppers-x.php">Toppers X</a></li>
                        <li><a href="toppers-xii.php">Toppers XII</a></li>
                    </ul>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Gallery</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="event_gallery.php">Event Gallery</a></li>
                        <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                    </ul>
                </li>
                <li>
                    <a href="blog.php" class="main">Blogs</a>
                </li>
                <li>
                    <a href="contact.php" class="main">Contact</a>
                </li>
            </ul>
            </nav>

            <div class="offcanvase__info--content mt--30">
                <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                <div class="offcanvase__info--content--social">
                    <p class="title">Follow Us:</p>
                    <div class="social__links">
                        <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

    <div class="search-input-area">
        <div class="container">
            <div class="search-input-inner">
                <div class="input-div">
                    <input class="search-input autocomplete ui-autocomplete-input" type="text" placeholder="Search by keyword or #" autocomplete="off">
                    <button><i class="far fa-search"></i></button>
                </div>
            </div>
        </div>
        <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
    </div>
    <!-- rts backto top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>
    <!-- rts back to top end -->
    <div id="anywhere-home" class="">
    </div>


    <!-- scripts -->
    <!-- jquery js -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- bootstrap 5.0.2 -->
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <!-- jquery ui js -->
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <!-- wow js -->
    <script src="assets/js/vendor/waw.js"></script>
    <!-- mobile menu -->
    <script src="assets/js/vendor/metismenu.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/vendor/magnifying-popup.js"></script>
    <!-- swiper JS 10.2.0 -->
    <script src="assets/js/plugins/swiper.js"></script>
    <!-- counterup -->
    <script src="assets/js/plugins/counterup.js"></script>
    <script src="assets/js/vendor/waypoint.js"></script>
    <!-- isotop mesonary -->
    <script src="assets/js/plugins/isotop.js"></script>
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/plugins/sticky-sidebar.js"></script>
    <script src="assets/js/plugins/resize-sensor.js"></script>
    <script src="assets/js/plugins/twinmax.js"></script>
    <!-- dymanic Contact Form -->
    <script src="assets/js/plugins/contact.form.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- main Js -->
    <script src="assets/js/jquery.flexslider.js"></script>
    <script src="assets/js/main.js"></script>

<script src="https://cdn.jsdelirv.net/npm/jquery@4.5.2/dist/jquery.min.js"></script>
</body>
</html><script>
    document.addEventListener('DOMContentLoaded', function() {
        var allTab = new bootstrap.Tab(document.querySelector('#all-tab'));
        allTab.show();
    });
</script>